import React, { useState } from 'react';
import {
  RaaSMetrics,
  AmrRobot,
} from '../types/robotics';
import {
  DollarSign,
  TrendingUp,
  ShieldCheck,
  Zap,
  Sliders,
  CheckCircle,
  Truck,
  ArrowUpRight,
} from 'lucide-react';

interface RaasEconomicsProps {
  metrics: RaaSMetrics;
  robots: AmrRobot[];
}

export const RaasEconomics: React.FC<RaasEconomicsProps> = ({
  metrics,
  robots,
}) => {
  const [additionalAmrs, setAdditionalAmrs] = useState(2);

  // Projected metrics with additional robots
  const currentTotalMovesMonth = Math.round(metrics.totalTonnageMoved * 1.4);
  const baseCostManual = currentTotalMovesMonth * metrics.costPerPalletForklift;
  const baseCostRaas = currentTotalMovesMonth * metrics.costPerPalletRaaS;
  const monthlySavings = baseCostManual - baseCostRaas;

  // Expansion simulation
  const expandedMoves = Math.round(currentTotalMovesMonth * (1 + (additionalAmrs / robots.length) * 0.85));
  const expandedSavings = Math.round(expandedMoves * (metrics.costPerPalletForklift - metrics.costPerPalletRaaS));

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 p-6 space-y-6 overflow-y-auto">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold tracking-tight text-white font-sans">
          RaaS (Robot-as-a-Service) Economics & SLA Portal
        </h1>
        <p className="text-xs text-slate-400 font-mono mt-0.5">
          Op-ex consumption metering, guaranteed SLA compliance, and fleet ROI analytics
        </p>
      </div>

      {/* RaaS Economics Summary Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Card 1: Cost per Pallet Moved */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-2">
          <div className="text-xs font-mono text-slate-400 flex items-center justify-between">
            <span>COST PER PALLET MOVED</span>
            <span className="text-emerald-400 font-bold">-86% REDUCTION</span>
          </div>
          <div className="flex items-baseline gap-3">
            <span className="text-3xl font-bold text-emerald-400 font-mono tabular-nums">
              ${metrics.costPerPalletRaaS.toFixed(2)}
            </span>
            <span className="text-xs text-slate-400 font-mono line-through">
              ${metrics.costPerPalletForklift.toFixed(2)} manual forklift
            </span>
          </div>
          <p className="text-slate-400 text-xs font-sans">
            Includes autonomous navigation software license, battery maintenance, and hardware replacement warranty.
          </p>
        </div>

        {/* Card 2: Net Monthly Operational Savings */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-2">
          <div className="text-xs font-mono text-slate-400 flex items-center justify-between">
            <span>MONTHLY OP-EX SAVINGS</span>
            <ArrowUpRight className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-3xl font-bold text-white font-mono tabular-nums">
            ${metrics.totalCostSavedMonth.toLocaleString()}
          </div>
          <p className="text-slate-400 text-xs font-sans">
            Eliminates human forklift operator shift premiums, deadheading idle time, and product impact shrinkage.
          </p>
        </div>

        {/* Card 3: Contract SLA Guarantee */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-2">
          <div className="text-xs font-mono text-slate-400 flex items-center justify-between">
            <span>SLA UPTIME COMMITMENT</span>
            <ShieldCheck className="w-4 h-4 text-sky-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold text-sky-400 font-mono tabular-nums">
              {metrics.slaAvailabilityPercent}%
            </span>
            <span className="text-xs text-slate-400 font-mono">
              (Req: {metrics.targetSlaPercent}%)
            </span>
          </div>
          <p className="text-slate-400 text-xs font-sans">
            Contract compliance verified. SLA breach credit risk: <span className="text-emerald-400 font-mono font-bold">$0.00</span>.
          </p>
        </div>
      </div>

      {/* Detailed Cost Comparison Breakdown */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
        <h2 className="text-sm font-bold text-white font-sans">
          Operational Expenditure Matrix: RaaS vs. Legacy Manned Material Handling
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-mono">
              <tr>
                <th className="py-3 px-4">COST COMPONENT</th>
                <th className="py-3 px-4">TRADITIONAL FORKLIFT FLEET</th>
                <th className="py-3 px-4">KINETIX RAAS AUTONOMY</th>
                <th className="py-3 px-4 text-right">VARIANCE / DELTA</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              <tr className="hover:bg-slate-800/30">
                <td className="py-3 px-4 font-medium text-slate-200">Operator Labor (24/7 Multi-Shift)</td>
                <td className="py-3 px-4 font-mono text-slate-400">$38,000 / mo</td>
                <td className="py-3 px-4 font-mono text-emerald-400">$0 / mo (Fully Autonomous)</td>
                <td className="py-3 px-4 font-mono text-right text-emerald-400 font-bold">-$38,000 / mo</td>
              </tr>
              <tr className="hover:bg-slate-800/30">
                <td className="py-3 px-4 font-medium text-slate-200">Equipment Lease / Subscription</td>
                <td className="py-3 px-4 font-mono text-slate-400">$8,200 / mo</td>
                <td className="py-3 px-4 font-mono text-slate-200">$9,400 / mo (All-inclusive RaaS)</td>
                <td className="py-3 px-4 font-mono text-right text-slate-400">+$1,200 / mo</td>
              </tr>
              <tr className="hover:bg-slate-800/30">
                <td className="py-3 px-4 font-medium text-slate-200">Preventative Maintenance & Tires</td>
                <td className="py-3 px-4 font-mono text-slate-400">$4,500 / mo</td>
                <td className="py-3 px-4 font-mono text-emerald-400">$0 / mo (Included in RaaS tier)</td>
                <td className="py-3 px-4 font-mono text-right text-emerald-400 font-bold">-$4,500 / mo</td>
              </tr>
              <tr className="hover:bg-slate-800/30">
                <td className="py-3 px-4 font-medium text-slate-200">Product Damage & Collision Shrink</td>
                <td className="py-3 px-4 font-mono text-slate-400">$2,800 / mo</td>
                <td className="py-3 px-4 font-mono text-emerald-400">&lt; $50 / mo (LiDAR 360 Safe)</td>
                <td className="py-3 px-4 font-mono text-right text-emerald-400 font-bold">-$2,750 / mo</td>
              </tr>
              <tr className="bg-slate-950 font-bold">
                <td className="py-3 px-4 text-white">NET OPERATIONAL EXPENDITURE</td>
                <td className="py-3 px-4 font-mono text-slate-300">$53,500 / mo</td>
                <td className="py-3 px-4 font-mono text-emerald-400">$9,450 / mo</td>
                <td className="py-3 px-4 font-mono text-right text-emerald-400 text-sm">
                  -$44,050 / mo (-82%)
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Fleet Capacity & Expansion Simulator */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-white font-sans flex items-center gap-2">
              <Sliders className="w-4 h-4 text-amber-400" />
              Dynamic Fleet Expansion Simulator
            </h2>
            <div className="text-xs text-slate-400 font-mono">
              Simulate on-demand RaaS scaling during peak seasonal fulfillment waves
            </div>
          </div>

          <div className="flex items-center gap-3 text-xs font-mono">
            <span className="text-slate-400">ADDITIONAL AMRS:</span>
            <span className="px-2.5 py-1 bg-amber-400/10 text-amber-400 border border-amber-400/30 rounded font-bold">
              +{additionalAmrs} Units
            </span>
          </div>
        </div>

        <input
          type="range"
          min="1"
          max="8"
          step="1"
          value={additionalAmrs}
          onChange={(e) => setAdditionalAmrs(parseInt(e.target.value))}
          className="w-full accent-amber-400 bg-slate-800"
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2 text-xs font-mono">
          <div className="bg-slate-950 border border-slate-800 rounded p-4">
            <div className="text-slate-400 mb-1">SCALED FLEET CAPACITY</div>
            <div className="text-xl font-bold text-white">{robots.length + additionalAmrs} AMRs</div>
            <div className="text-[11px] text-slate-500 mt-1">Eliminates peak staging bottleneck</div>
          </div>
          <div className="bg-slate-950 border border-slate-800 rounded p-4">
            <div className="text-slate-400 mb-1">PROJECTED MONTHLY MOVES</div>
            <div className="text-xl font-bold text-sky-400">{expandedMoves.toLocaleString()} pallets</div>
            <div className="text-[11px] text-slate-500 mt-1">+{((additionalAmrs / robots.length) * 85).toFixed(0)}% throughput expansion</div>
          </div>
          <div className="bg-slate-950 border border-slate-800 rounded p-4">
            <div className="text-slate-400 mb-1">PROJECTED MONTHLY SAVINGS</div>
            <div className="text-xl font-bold text-emerald-400">${expandedSavings.toLocaleString()}</div>
            <div className="text-[11px] text-emerald-400/70 mt-1">Incremental ROI: 5.2x</div>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  Task,
  AmrRobot,
  WarehouseZone,
  TaskType,
  TaskPriority,
} from '../types/robotics';
import {
  Plus,
  Play,
  RotateCcw,
  Sparkles,
  ArrowRight,
  Filter,
  CheckCircle2,
  Clock,
  AlertCircle,
  Truck,
  Box,
  Layers,
} from 'lucide-react';
import { autoAllocateTask } from '../utils/roboticsEngine';

interface MissionPlannerProps {
  tasks: Task[];
  robots: AmrRobot[];
  zones: WarehouseZone[];
  onDispatchTask: (newTask: Omit<Task, 'id' | 'createdAt' | 'startedAt' | 'completedAt' | 'progressPercent'>, assignedRobotId: string | null) => void;
  onCancelTask: (taskId: string) => void;
  onAutoAllocateAll: () => void;
  onSelectRobot: (robotId: string) => void;
}

export const MissionPlanner: React.FC<MissionPlannerProps> = ({
  tasks,
  robots,
  zones,
  onDispatchTask,
  onCancelTask,
  onAutoAllocateAll,
  onSelectRobot,
}) => {
  const [filterStatus, setFilterStatus] = useState<'all' | 'in_progress' | 'queued' | 'completed'>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // New task form state
  const [taskType, setTaskType] = useState<TaskType>('pallet_transport');
  const [priority, setPriority] = useState<TaskPriority>('P2_HIGH');
  const [sourceBay, setSourceBay] = useState('Dock D-01');
  const [destBay, setDestBay] = useState('Rack A1-01');
  const [sku, setSku] = useState('SKU-POWERTRAIN-44');
  const [skuDesc, setSkuDesc] = useState('Inverter Power Module Bins');
  const [weightKg, setWeightKg] = useState(650);
  const [assigneeMode, setAssigneeMode] = useState<'auto' | string>('auto');

  // Filter tasks
  const filteredTasks = tasks.filter((t) => {
    if (filterStatus === 'all') return true;
    if (filterStatus === 'in_progress') return t.status === 'moving_to_drop' || t.status === 'moving_to_pickup' || t.status === 'loading';
    if (filterStatus === 'queued') return t.status === 'queued';
    if (filterStatus === 'completed') return t.status === 'completed';
    return true;
  });

  // Collect all bays from zones
  const allBays = zones.flatMap((z) => (z.bays || []).map((b) => ({ ...b, zoneName: z.name })));

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    const sourceObj = allBays.find((b) => b.name === sourceBay) || { x: 8, y: 12, zoneName: 'Inbound Docks' };
    const destObj = allBays.find((b) => b.name === destBay) || { x: 34, y: 28, zoneName: 'Racking Aisle' };

    let assignedId: string | null = null;
    if (assigneeMode === 'auto') {
      const mockTask: Task = {
        id: 'PREVIEW',
        type: taskType,
        priority,
        sourceZone: sourceObj.zoneName,
        sourceLocation: { x: sourceObj.x, y: sourceObj.y },
        sourceBay,
        destinationZone: destObj.zoneName,
        destinationLocation: { x: destObj.x, y: destObj.y },
        destinationBay: destBay,
        sku,
        skuDescription: skuDesc,
        weightKg,
        assignedAmrId: null,
        status: 'queued',
        progressPercent: 0,
        createdAt: '',
        startedAt: null,
        completedAt: null,
        sourceSystem: 'MANUAL_DISPATCH',
      };
      const alloc = autoAllocateTask(mockTask, robots);
      assignedId = alloc.bestRobotId;
    } else {
      assignedId = assigneeMode;
    }

    onDispatchTask(
      {
        type: taskType,
        priority,
        sourceZone: sourceObj.zoneName,
        sourceLocation: { x: sourceObj.x, y: sourceObj.y },
        sourceBay,
        destinationZone: destObj.zoneName,
        destinationLocation: { x: destObj.x, y: destObj.y },
        destinationBay: destBay,
        sku,
        skuDescription: skuDesc,
        weightKg,
        assignedAmrId: assignedId,
        status: assignedId ? 'moving_to_pickup' : 'queued',
        sourceSystem: 'MANUAL_DISPATCH',
      },
      assignedId
    );

    setIsModalOpen(false);
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 p-6 space-y-6 overflow-y-auto">
      {/* Top Banner / Metrics */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white font-sans">
            Missions & Dynamic Task Allocation
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Cost-matrix matching engine for warehouse intra-logistics and manufacturing replenishment
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onAutoAllocateAll}
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 rounded text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Auto-Allocate Queued</span>
          </button>

          <button
            onClick={() => setIsModalOpen(true)}
            className="px-3 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-xs flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Dispatch New Mission</span>
          </button>
        </div>
      </div>

      {/* Task Queue Filters & Metrics Strip */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-900 border border-slate-800 rounded-lg text-xs">
        <div className="flex items-center gap-1">
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-3 py-1.5 rounded transition-colors ${
              filterStatus === 'all' ? 'bg-slate-800 text-white font-medium shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Missions ({tasks.length})
          </button>
          <button
            onClick={() => setFilterStatus('in_progress')}
            className={`px-3 py-1.5 rounded transition-colors ${
              filterStatus === 'in_progress' ? 'bg-slate-800 text-sky-400 font-medium shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            In-Progress ({tasks.filter((t) => t.status === 'moving_to_drop' || t.status === 'moving_to_pickup').length})
          </button>
          <button
            onClick={() => setFilterStatus('queued')}
            className={`px-3 py-1.5 rounded transition-colors ${
              filterStatus === 'queued' ? 'bg-slate-800 text-amber-400 font-medium shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Queued Backlog ({tasks.filter((t) => t.status === 'queued').length})
          </button>
          <button
            onClick={() => setFilterStatus('completed')}
            className={`px-3 py-1.5 rounded transition-colors ${
              filterStatus === 'completed' ? 'bg-slate-800 text-emerald-400 font-medium shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Completed ({tasks.filter((t) => t.status === 'completed').length})
          </button>
        </div>

        <div className="text-slate-400 font-mono text-[11px] hidden sm:block">
          Average Dispatch Latency: <span className="text-white font-bold">1.4s</span> · Allocation Efficiency: <span className="text-emerald-400 font-bold">98.4%</span>
        </div>
      </div>

      {/* Tasks Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-mono">
              <tr>
                <th className="py-3 px-4">TASK ID / PRIORITY</th>
                <th className="py-3 px-4">MISSION TYPE</th>
                <th className="py-3 px-4">ROUTING (SOURCE → DEST)</th>
                <th className="py-3 px-4">SKU / PAYLOAD</th>
                <th className="py-3 px-4">ASSIGNED AMR</th>
                <th className="py-3 px-4">PROGRESS</th>
                <th className="py-3 px-4 text-right">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {filteredTasks.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-500 font-mono">
                    No missions found matching current filter state.
                  </td>
                </tr>
              ) : (
                filteredTasks.map((task) => {
                  const assignedRobot = robots.find((r) => r.id === task.assignedAmrId);

                  return (
                    <tr key={task.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3.5 px-4 font-mono">
                        <div className="font-bold text-slate-200">{task.id}</div>
                        <div className="flex items-center gap-1.5 mt-0.5 text-[11px]">
                          <span
                            className={`font-semibold ${
                              task.priority === 'P1_CRITICAL'
                                ? 'text-rose-400'
                                : task.priority === 'P2_HIGH'
                                ? 'text-amber-400'
                                : 'text-slate-400'
                            }`}
                          >
                            {task.priority.replace('_', ' ')}
                          </span>
                          <span className="text-slate-600">·</span>
                          <span className="text-slate-500">{task.sourceSystem}</span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-medium text-slate-200 capitalize">
                          {task.type.replace(/_/g, ' ')}
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono">Created {task.createdAt}</div>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2 font-mono text-slate-300">
                          <span>{task.sourceBay}</span>
                          <ArrowRight className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                          <span className="text-amber-300 font-medium">{task.destinationBay}</span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-mono text-slate-200">{task.sku}</div>
                        <div className="text-[11px] text-slate-400 truncate max-w-[200px]">
                          {task.skuDescription} · <span className="font-mono">{task.weightKg} kg</span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        {assignedRobot ? (
                          <button
                            onClick={() => onSelectRobot(assignedRobot.id)}
                            className="flex items-center gap-1.5 text-sky-400 hover:text-sky-300 font-mono hover:underline"
                          >
                            <Truck className="w-3.5 h-3.5" />
                            <span>{assignedRobot.callsign} ({assignedRobot.id})</span>
                          </button>
                        ) : (
                          <span className="font-mono text-amber-400/80 italic">Unassigned (Queued)</span>
                        )}
                      </td>

                      <td className="py-3.5 px-4 w-40">
                        <div className="flex items-center justify-between text-[11px] font-mono mb-1">
                          <span className="capitalize text-slate-400">{task.status.replace(/_/g, ' ')}</span>
                          <span className="text-slate-200">{task.progressPercent}%</span>
                        </div>
                        <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                          <div
                            className={`h-1.5 rounded-full transition-all ${
                              task.status === 'completed'
                                ? 'bg-emerald-500'
                                : 'bg-sky-400'
                            }`}
                            style={{ width: `${task.progressPercent}%` }}
                          />
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        {task.status !== 'completed' && task.status !== 'canceled' && (
                          <button
                            onClick={() => onCancelTask(task.id)}
                            className="px-2.5 py-1 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded transition-colors text-[11px] font-mono"
                          >
                            Cancel
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Dispatch New Mission Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-lg w-full p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white">Dispatch Robotic Mission</h3>
                <p className="text-xs text-slate-400 font-mono">Create and assign an AMR transport or replenishment order</p>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateTask} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-mono mb-1">MISSION TYPE</label>
                  <select
                    value={taskType}
                    onChange={(e) => setTaskType(e.target.value as TaskType)}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-2 text-slate-200"
                  >
                    <option value="pallet_transport">Pallet Transport</option>
                    <option value="rack_replenish">Rack Replenishment</option>
                    <option value="outbound_dispatch">Outbound Dispatch</option>
                    <option value="wip_assembly_transfer">WIP Assembly Transfer</option>
                    <option value="bin_shuttle">Bin Shuttle</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-mono mb-1">PRIORITY</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as TaskPriority)}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-2 text-slate-200"
                  >
                    <option value="P1_CRITICAL">P1 - Critical (Immediate)</option>
                    <option value="P2_HIGH">P2 - High Priority</option>
                    <option value="P3_NORMAL">P3 - Normal</option>
                    <option value="P4_LOW">P4 - Low / Routine</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-mono mb-1">SOURCE LOCATION</label>
                  <select
                    value={sourceBay}
                    onChange={(e) => setSourceBay(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-2 text-slate-200"
                  >
                    {allBays.map((bay, bIdx) => (
                      <option key={bIdx} value={bay.name}>
                        {bay.name} ({bay.zoneName.split(' ')[0]})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-mono mb-1">DESTINATION BAY</label>
                  <select
                    value={destBay}
                    onChange={(e) => setDestBay(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-2 text-slate-200"
                  >
                    {allBays.map((bay, bIdx) => (
                      <option key={bIdx} value={bay.name}>
                        {bay.name} ({bay.zoneName.split(' ')[0]})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2">
                  <label className="block text-slate-400 font-mono mb-1">SKU / ITEM CODE</label>
                  <input
                    type="text"
                    value={sku}
                    onChange={(e) => setSku(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-2 text-slate-200 font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-mono mb-1">WEIGHT (KG)</label>
                  <input
                    type="number"
                    min="10"
                    max="1500"
                    value={weightKg}
                    onChange={(e) => setWeightKg(parseInt(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-2 text-slate-200 font-mono"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-mono mb-1">DESCRIPTION</label>
                <input
                  type="text"
                  value={skuDesc}
                  onChange={(e) => setSkuDesc(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-2 text-slate-200"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-mono mb-1">ASSIGNMENT STRATEGY</label>
                <select
                  value={assigneeMode}
                  onChange={(e) => setAssigneeMode(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-2 text-slate-200 font-mono"
                >
                  <option value="auto">Auto-Select Nearest Capable AMR (Hungarian Optimization)</option>
                  {robots
                    .filter((r) => r.maxPayloadKg >= weightKg && r.status !== 'e_stop')
                    .map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.callsign} ({r.id}) - {r.model.split(' ')[0]} [Bat: {r.batterySoc}% | Cap: {r.maxPayloadKg}kg]
                      </option>
                    ))}
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded font-mono shadow-sm"
                >
                  Dispatch Order
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import {
  AmrRobot,
  Task,
  Vda5050Order,
} from '../types/robotics';
import {
  X,
  BatteryCharging,
  Zap,
  Radio,
  Gauge,
  Thermometer,
  ShieldAlert,
  ArrowUp,
  ArrowDown,
  RotateCcw,
  RotateCw,
  Compass,
  FileCode,
  AlertTriangle,
  Play,
  Copy,
  Check,
} from 'lucide-react';
import { generateVda5050Order } from '../utils/roboticsEngine';

interface RobotDetailModalProps {
  robot: AmrRobot | null;
  tasks: Task[];
  onClose: () => void;
  onSendToCharge: (robotId: string) => void;
  onToggleRobotEStop: (robotId: string) => void;
  onTeleopMove: (robotId: string, direction: 'forward' | 'backward' | 'left' | 'right' | 'halt') => void;
  onSetSpeedLimiter: (robotId: string, limit: number) => void;
}

export const RobotDetailModal: React.FC<RobotDetailModalProps> = ({
  robot,
  tasks,
  onClose,
  onSendToCharge,
  onToggleRobotEStop,
  onTeleopMove,
  onSetSpeedLimiter,
}) => {
  const [activeTab, setActiveTab] = useState<'telemetry' | 'teleop' | 'vda5050' | 'diagnostics'>('telemetry');
  const [radarAngle, setRadarAngle] = useState(0);
  const [copiedJson, setCopiedJson] = useState(false);

  // Radar sweep animation
  useEffect(() => {
    const interval = setInterval(() => {
      setRadarAngle((prev) => (prev + 12) % 360);
    }, 50);
    return () => clearInterval(interval);
  }, []);

  if (!robot) return null;

  const currentTask = tasks.find((t) => t.id === robot.currentTaskId);
  const vdaOrder: Vda5050Order | null = currentTask ? generateVda5050Order(robot, currentTask) : null;

  const copyVdaJson = () => {
    if (!vdaOrder) return;
    navigator.clipboard.writeText(JSON.stringify(vdaOrder, null, 2));
    setCopiedJson(true);
    setTimeout(() => setCopiedJson(false), 2000);
  };

  return (
    <div className="fixed inset-y-0 right-0 w-full max-w-xl bg-slate-900/98 backdrop-blur border-l border-slate-800 shadow-2xl z-40 flex flex-col text-slate-200 overflow-hidden">
      {/* Drawer Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/70">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded bg-slate-800 border border-slate-700 flex items-center justify-center font-mono font-bold text-amber-400">
            {robot.id.replace('AMR-', '')}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white font-sans">{robot.callsign}</h2>
              <span className="text-xs font-mono text-slate-400">({robot.id})</span>
            </div>
            <div className="text-xs text-slate-400 font-mono">{robot.model}</div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Status Badge */}
          <span
            className={`px-2.5 py-1 text-xs font-mono font-medium rounded uppercase ${
              robot.status === 'in_transit'
                ? 'bg-sky-950 text-sky-400 border border-sky-800'
                : robot.status === 'charging'
                ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                : robot.status === 'e_stop'
                ? 'bg-rose-950 text-rose-400 border border-rose-800'
                : robot.status === 'blocked'
                ? 'bg-amber-950 text-amber-400 border border-amber-800'
                : 'bg-slate-800 text-slate-300 border border-slate-700'
            }`}
          >
            {robot.status.replace('_', ' ')}
          </span>

          <button
            onClick={onClose}
            className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center px-6 border-b border-slate-800 bg-slate-950/40 text-xs font-medium">
        <button
          onClick={() => setActiveTab('telemetry')}
          className={`py-2.5 px-3 border-b-2 transition-colors ${
            activeTab === 'telemetry'
              ? 'border-amber-400 text-amber-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Live Telemetry
        </button>
        <button
          onClick={() => setActiveTab('teleop')}
          className={`py-2.5 px-3 border-b-2 transition-colors ${
            activeTab === 'teleop'
              ? 'border-amber-400 text-amber-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Manual Teleoperation
        </button>
        <button
          onClick={() => setActiveTab('vda5050')}
          className={`py-2.5 px-3 border-b-2 transition-colors ${
            activeTab === 'vda5050'
              ? 'border-amber-400 text-amber-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          VDA 5050 Protocol
        </button>
        <button
          onClick={() => setActiveTab('diagnostics')}
          className={`py-2.5 px-3 border-b-2 transition-colors ${
            activeTab === 'diagnostics'
              ? 'border-amber-400 text-amber-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Diagnostics ({robot.diagnosticFaults.length})
        </button>
      </div>

      {/* Drawer Body */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {activeTab === 'telemetry' && (
          <div className="space-y-6">
            {/* Live 360 LiDAR Scan Radar Visualizer */}
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3 text-xs">
                <span className="font-mono text-slate-400 flex items-center gap-1.5">
                  <Radio className="w-3.5 h-3.5 text-sky-400 animate-pulse" />
                  360° SOLID-STATE LIDAR SCANNER
                </span>
                <span className="font-mono text-sky-400 tabular-nums">
                  MIN CLEARANCE: {robot.lidarClearance.toFixed(1)}m
                </span>
              </div>

              {/* Polar Plot Canvas / SVG */}
              <div className="relative w-full aspect-square max-w-[280px] mx-auto flex items-center justify-center">
                <svg viewBox="-50 -50 100 100" className="w-full h-full">
                  {/* Concentric distance rings */}
                  <circle cx="0" cy="0" r="10" fill="none" stroke="#1e293b" strokeWidth="0.5" />
                  <circle cx="0" cy="0" r="20" fill="none" stroke="#1e293b" strokeWidth="0.5" />
                  <circle cx="0" cy="0" r="30" fill="none" stroke="#1e293b" strokeWidth="0.5" />
                  <circle cx="0" cy="0" r="40" fill="none" stroke="#1e293b" strokeWidth="0.5" />

                  {/* Crosshairs */}
                  <line x1="-45" y1="0" x2="45" y2="0" stroke="#1e293b" strokeWidth="0.5" />
                  <line x1="0" y1="-45" x2="0" y2="45" stroke="#1e293b" strokeWidth="0.5" />

                  {/* Range labels */}
                  <text x="2" y="-12" fill="#64748b" fontSize="3" fontFamily="JetBrains Mono">2m</text>
                  <text x="2" y="-22" fill="#64748b" fontSize="3" fontFamily="JetBrains Mono">4m</text>
                  <text x="2" y="-32" fill="#64748b" fontSize="3" fontFamily="JetBrains Mono">6m</text>
                  <text x="2" y="-42" fill="#64748b" fontSize="3" fontFamily="JetBrains Mono">8m</text>

                  {/* Simulated obstacles & reflections */}
                  <circle cx="15" cy="-24" r="1.5" fill="#38bdf8" opacity="0.9" />
                  <circle cx="-28" cy="18" r="1.5" fill="#38bdf8" opacity="0.7" />
                  <circle cx="20" cy="30" r="1.5" fill="#38bdf8" opacity="0.8" />

                  {/* Rotating radar sweep ray */}
                  <line
                    x1="0"
                    y1="0"
                    x2={Math.cos((radarAngle * Math.PI) / 180) * 44}
                    y2={Math.sin((radarAngle * Math.PI) / 180) * 44}
                    stroke="#38bdf8"
                    strokeWidth="1"
                    strokeOpacity="0.8"
                  />

                  {/* AMR Center Hub */}
                  <circle cx="0" cy="0" r="3" fill="#f59e0b" />
                </svg>
              </div>
            </div>

            {/* Core Telemetry Grid */}
            <div className="grid grid-cols-2 gap-3">
              {/* Battery SOC */}
              <div className="bg-slate-950 border border-slate-800 rounded p-3">
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                  <span className="flex items-center gap-1">
                    <BatteryCharging className="w-3.5 h-3.5 text-emerald-400" />
                    BATTERY SOC
                  </span>
                  <span className="font-mono text-emerald-400">{robot.batteryVoltage} V</span>
                </div>
                <div className="text-xl font-bold font-mono text-white tabular-nums">
                  {robot.batterySoc}%
                </div>
                <div className="w-full bg-slate-800 rounded-full h-1.5 mt-2">
                  <div
                    className="bg-emerald-500 h-1.5 rounded-full"
                    style={{ width: `${robot.batterySoc}%` }}
                  />
                </div>
                <div className="text-[10px] text-slate-500 font-mono mt-1">Health (SOH): {robot.batteryHealth}%</div>
              </div>

              {/* Speed & Heading */}
              <div className="bg-slate-950 border border-slate-800 rounded p-3">
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                  <span className="flex items-center gap-1">
                    <Gauge className="w-3.5 h-3.5 text-sky-400" />
                    VELOCITY
                  </span>
                  <span className="font-mono text-slate-400">{robot.heading}° HDG</span>
                </div>
                <div className="text-xl font-bold font-mono text-white tabular-nums">
                  {robot.speed.toFixed(2)} <span className="text-xs text-slate-400">m/s</span>
                </div>
                <div className="text-[10px] text-slate-400 font-mono mt-2">
                  Max: {robot.maxSpeed} m/s · Limit: {(robot.speedLimiter * 100).toFixed(0)}%
                </div>
              </div>

              {/* Motor Temperature */}
              <div className="bg-slate-950 border border-slate-800 rounded p-3">
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                  <span className="flex items-center gap-1">
                    <Thermometer className="w-3.5 h-3.5 text-amber-400" />
                    DRIVE MOTOR TEMP
                  </span>
                  <span className="font-mono text-emerald-400">NOMINAL</span>
                </div>
                <div className="text-xl font-bold font-mono text-white tabular-nums">
                  {robot.motorTempC.toFixed(1)}°C
                </div>
                <div className="text-[10px] text-slate-500 font-mono mt-2">Thermal limit: 75.0°C</div>
              </div>

              {/* Payload Weight */}
              <div className="bg-slate-950 border border-slate-800 rounded p-3">
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                  <span className="flex items-center gap-1">
                    <Zap className="w-3.5 h-3.5 text-yellow-400" />
                    CURRENT PAYLOAD
                  </span>
                  <span className="font-mono text-slate-400">CAP: {robot.maxPayloadKg} kg</span>
                </div>
                <div className="text-xl font-bold font-mono text-white tabular-nums">
                  {robot.payloadKg} <span className="text-xs text-slate-400">kg</span>
                </div>
                <div className="text-[10px] text-slate-500 font-mono mt-2">
                  Utilization: {((robot.payloadKg / robot.maxPayloadKg) * 100).toFixed(0)}%
                </div>
              </div>
            </div>

            {/* Current Active Mission Banner */}
            <div className="bg-slate-950 border border-slate-800 rounded p-4">
              <div className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">
                ACTIVE MISSION LINKAGE
              </div>
              {currentTask ? (
                <div className="space-y-2 text-xs">
                  <div className="flex items-center justify-between font-mono">
                    <span className="text-amber-400 font-bold">{currentTask.id}</span>
                    <span className="text-slate-400 uppercase">{currentTask.type.replace('_', ' ')}</span>
                  </div>
                  <div className="text-slate-300">{currentTask.skuDescription}</div>
                  <div className="flex items-center justify-between text-slate-400 pt-1 font-mono">
                    <span>From: {currentTask.sourceBay}</span>
                    <span>To: {currentTask.destinationBay}</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-1.5 mt-2">
                    <div
                      className="bg-sky-400 h-1.5 rounded-full transition-all"
                      style={{ width: `${currentTask.progressPercent}%` }}
                    />
                  </div>
                </div>
              ) : (
                <div className="text-xs text-slate-500 font-mono">
                  No active mission assigned. Robot in autonomous standby / standby queue.
                </div>
              )}
            </div>

            {/* Quick Actions */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => onSendToCharge(robot.id)}
                disabled={robot.status === 'charging'}
                className="flex-1 px-4 py-2.5 bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-700/60 text-emerald-300 rounded text-xs font-medium transition-colors disabled:opacity-50"
              >
                Send to Rapid Charger
              </button>
              <button
                onClick={() => onToggleRobotEStop(robot.id)}
                className={`px-4 py-2.5 rounded text-xs font-medium border transition-colors ${
                  robot.status === 'e_stop'
                    ? 'bg-emerald-900 text-white border-emerald-600'
                    : 'bg-rose-950/80 hover:bg-rose-900 border-rose-700 text-rose-300'
                }`}
              >
                {robot.status === 'e_stop' ? 'Clear AMR E-Stop' : 'AMR E-Stop'}
              </button>
            </div>
          </div>
        )}

        {activeTab === 'teleop' && (
          <div className="space-y-6">
            <div className="p-3 bg-amber-950/30 border border-amber-800/60 text-amber-300 text-xs rounded">
              <div className="font-bold mb-1">MANUAL OVERRIDE TELEOPERATION</div>
              Autonomous mission will be suspended while manual jog commands are dispatched.
            </div>

            {/* Speed Limiter Slider */}
            <div className="bg-slate-950 border border-slate-800 rounded p-4 space-y-2">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-400">TELEOP SPEED CEILING</span>
                <span className="text-amber-400">{(robot.speedLimiter * 100).toFixed(0)}% ({(robot.maxSpeed * robot.speedLimiter).toFixed(2)} m/s)</span>
              </div>
              <input
                type="range"
                min="0.2"
                max="1.0"
                step="0.1"
                value={robot.speedLimiter}
                onChange={(e) => onSetSpeedLimiter(robot.id, parseFloat(e.target.value))}
                className="w-full accent-amber-400 bg-slate-800"
              />
            </div>

            {/* Directional Jog D-Pad */}
            <div className="bg-slate-950 border border-slate-800 rounded p-6 flex flex-col items-center justify-center">
              <div className="text-xs font-mono text-slate-400 mb-4">DIRECTIONAL VECTOR CONTROL</div>

              <div className="grid grid-cols-3 gap-2 w-48">
                {/* Row 1 */}
                <div />
                <button
                  onClick={() => onTeleopMove(robot.id, 'forward')}
                  className="p-4 bg-slate-800 hover:bg-slate-700 active:bg-amber-500 active:text-slate-950 text-slate-200 rounded flex items-center justify-center transition-all"
                  title="Forward Jog"
                >
                  <ArrowUp className="w-5 h-5" />
                </button>
                <div />

                {/* Row 2 */}
                <button
                  onClick={() => onTeleopMove(robot.id, 'left')}
                  className="p-4 bg-slate-800 hover:bg-slate-700 active:bg-amber-500 active:text-slate-950 text-slate-200 rounded flex items-center justify-center transition-all"
                  title="Rotate Left"
                >
                  <RotateCcw className="w-5 h-5" />
                </button>
                <button
                  onClick={() => onTeleopMove(robot.id, 'halt')}
                  className="p-4 bg-rose-950 hover:bg-rose-900 border border-rose-700 text-rose-300 font-mono text-xs font-bold rounded flex items-center justify-center transition-all"
                  title="Halt"
                >
                  HALT
                </button>
                <button
                  onClick={() => onTeleopMove(robot.id, 'right')}
                  className="p-4 bg-slate-800 hover:bg-slate-700 active:bg-amber-500 active:text-slate-950 text-slate-200 rounded flex items-center justify-center transition-all"
                  title="Rotate Right"
                >
                  <RotateCw className="w-5 h-5" />
                </button>

                {/* Row 3 */}
                <div />
                <button
                  onClick={() => onTeleopMove(robot.id, 'backward')}
                  className="p-4 bg-slate-800 hover:bg-slate-700 active:bg-amber-500 active:text-slate-950 text-slate-200 rounded flex items-center justify-center transition-all"
                  title="Reverse Jog"
                >
                  <ArrowDown className="w-5 h-5" />
                </button>
                <div />
              </div>
            </div>
          </div>
        )}

        {activeTab === 'vda5050' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Standard VDA 5050 v2.0 Payload Protocol</span>
              {vdaOrder && (
                <button
                  onClick={copyVdaJson}
                  className="flex items-center gap-1 text-amber-400 hover:text-amber-300 font-mono"
                >
                  {copiedJson ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedJson ? 'Copied' : 'Copy JSON'}</span>
                </button>
              )}
            </div>

            <pre className="bg-slate-950 border border-slate-800 p-4 rounded text-[11px] font-mono text-emerald-400 overflow-x-auto max-h-[420px]">
              {vdaOrder ? JSON.stringify(vdaOrder, null, 2) : JSON.stringify({
                header: {
                  headerId: 84920,
                  timestamp: new Date().toISOString(),
                  version: '2.0.0',
                  manufacturer: 'KINETIX',
                  serialNumber: robot.id,
                },
                state: {
                  operatingMode: robot.status.toUpperCase(),
                  batteryState: {
                    batteryCharge: robot.batterySoc,
                    batteryVoltage: robot.batteryVoltage,
                    batteryHealth: robot.batteryHealth,
                  },
                  safetyState: {
                    eStop: robot.status === 'e_stop' ? 'MANUAL' : 'NONE',
                    fieldViolation: robot.status === 'blocked',
                  },
                },
              }, null, 2)}
            </pre>
          </div>
        )}

        {activeTab === 'diagnostics' && (
          <div className="space-y-4">
            <div className="text-xs font-mono text-slate-400 uppercase tracking-wider">
              ONBOARD DIAGNOSTIC TROUBLE CODES (DTC)
            </div>

            {robot.diagnosticFaults.length === 0 ? (
              <div className="p-6 bg-slate-950 border border-slate-800 rounded text-center text-xs text-emerald-400 font-mono">
                All subsystem checks nominal. Zero active fault flags.
              </div>
            ) : (
              <div className="space-y-3">
                {robot.diagnosticFaults.map((fault, fIdx) => (
                  <div
                    key={fIdx}
                    className="p-3 bg-amber-950/20 border border-amber-800/60 rounded text-xs space-y-1"
                  >
                    <div className="flex items-center justify-between font-mono">
                      <span className="text-amber-400 font-bold">{fault.code}</span>
                      <span className="text-slate-500">{fault.timestamp}</span>
                    </div>
                    <div className="text-slate-300">{fault.message}</div>
                  </div>
                ))}
              </div>
            )}

            {/* Hardware specs summary */}
            <div className="bg-slate-950 border border-slate-800 rounded p-4 text-xs font-mono space-y-2">
              <div className="text-slate-400 font-bold mb-2">HARDWARE SPECIFICATIONS</div>
              <div className="flex justify-between"><span className="text-slate-500">Firmware Build:</span><span className="text-slate-200">{robot.firmware}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Static IP:</span><span className="text-slate-200">{robot.ipAddress}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Lifetime Odometer:</span><span className="text-slate-200">{robot.totalDistanceKm.toFixed(1)} km</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Operating Hours:</span><span className="text-slate-200">{robot.operatingHours.toFixed(1)} hrs</span></div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  AmrRobot,
  RaaSMetrics,
} from '../types/robotics';
import {
  Activity,
  Gauge,
  BatteryCharging,
  AlertTriangle,
  Download,
  Calendar,
  CheckCircle,
  Thermometer,
  ShieldCheck,
  TrendingUp,
} from 'lucide-react';

interface TelemetryAnalyticsProps {
  robots: AmrRobot[];
  metrics: RaaSMetrics;
}

export const TelemetryAnalytics: React.FC<TelemetryAnalyticsProps> = ({
  robots,
  metrics,
}) => {
  const [scrubberHour, setScrubberHour] = useState(10);

  // Hourly simulated battery and throughput profile
  const hourlyData = [
    { hour: '06:00', avgSoc: 96, moves: 18, kwH: 14.2 },
    { hour: '07:00', avgSoc: 89, moves: 42, kwH: 26.5 },
    { hour: '08:00', avgSoc: 78, moves: 68, kwH: 38.0 },
    { hour: '09:00', avgSoc: 71, moves: 82, kwH: 44.1 },
    { hour: '10:00', avgSoc: 74, moves: 94, kwH: 49.8 },
    { hour: '11:00', avgSoc: 65, moves: 88, kwH: 46.2 },
    { hour: '12:00', avgSoc: 82, moves: 34, kwH: 20.1 },
    { hour: '13:00', avgSoc: 76, moves: 79, kwH: 41.5 },
    { hour: '14:00', avgSoc: 68, moves: 86, kwH: 45.9 },
  ];

  const handleExportTelemetry = () => {
    const data = {
      exportTimestamp: new Date().toISOString(),
      facility: 'KINETIX-CENTRAL-01',
      metrics,
      fleetSummary: robots.map((r) => ({
        id: r.id,
        callsign: r.callsign,
        model: r.model,
        batterySoc: r.batterySoc,
        batteryVoltage: r.batteryVoltage,
        speed: r.speed,
        motorTempC: r.motorTempC,
        wifiRssi: r.wifiRssi,
        lidarClearance: r.lidarClearance,
        totalKm: r.totalDistanceKm,
        operatingHours: r.operatingHours,
        faults: r.diagnosticFaults,
      })),
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `kinetix_fleet_telemetry_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 p-6 space-y-6 overflow-y-auto">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white font-sans">
            Fleet Telemetry & Diagnostics
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Real-time physical sensor signals, OEE efficiency telemetry, and predictive maintenance logs
          </p>
        </div>

        <button
          onClick={handleExportTelemetry}
          className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-xs font-medium flex items-center gap-1.5 transition-colors"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Telemetry JSON</span>
        </button>
      </div>

      {/* Industrial OEE Breakdown Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1 font-mono">
            <span>FLEET AVAILABILITY</span>
            <span className="text-emerald-400 font-bold">NOMINAL</span>
          </div>
          <div className="text-2xl font-bold text-white font-mono tabular-nums">
            {metrics.slaAvailabilityPercent}%
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">
            Target SLA: {metrics.targetSlaPercent}% · Uptime: 99.82%
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1 font-mono">
            <span>PERFORMANCE EFFICIENCY</span>
            <TrendingUp className="w-3.5 h-3.5 text-sky-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono tabular-nums">
            96.4%
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">
            Avg Cycle Time: {metrics.averageCycleTimeMinutes}m / pallet
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1 font-mono">
            <span>TOTAL TONNAGE MOVED</span>
            <Activity className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono tabular-nums">
            {metrics.totalTonnageMoved.toLocaleString()} <span className="text-xs text-slate-400 font-normal">tons</span>
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">
            Fleet Hours: {metrics.totalFleetHours.toFixed(1)} hrs
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1 font-mono">
            <span>SAFETY INCIDENTS</span>
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400 font-mono tabular-nums">
            0 <span className="text-xs text-slate-400 font-normal">trips</span>
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">
            ISO 3691-4 Safety Interlocks 100% Valid
          </div>
        </div>
      </div>

      {/* SVG Time-Series Chart: Fleet Battery & Throughput Curve */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-white font-sans">
              Fleet Battery Discharge & Throughput Hourly Curve
            </h2>
            <div className="text-xs text-slate-400 font-mono">
              Correlation between mission throughput volume and state-of-charge decay
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-0.5 bg-emerald-400 inline-block" />
              <span className="text-slate-300">Avg Battery SOC %</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-0.5 bg-sky-400 inline-block" />
              <span className="text-slate-300">Pallet Moves / Hr</span>
            </div>
          </div>
        </div>

        {/* SVG Curve */}
        <div className="relative w-full h-52 bg-slate-950 border border-slate-800 rounded p-4">
          <svg viewBox="0 0 100 50" className="w-full h-full overflow-visible" preserveAspectRatio="none">
            {/* Grid lines */}
            <line x1="0" y1="10" x2="100" y2="10" stroke="#1e293b" strokeWidth="0.5" strokeDasharray="1 1" />
            <line x1="0" y1="25" x2="100" y2="25" stroke="#1e293b" strokeWidth="0.5" strokeDasharray="1 1" />
            <line x1="0" y1="40" x2="100" y2="40" stroke="#1e293b" strokeWidth="0.5" strokeDasharray="1 1" />

            {/* Battery Curve (Emerald) */}
            <path
              d="M 5 4 L 16 9 L 28 15 L 40 18 L 52 17 L 64 22 L 76 13 L 88 16 L 98 20"
              fill="none"
              stroke="#10b981"
              strokeWidth="1.2"
            />
            {/* Throughput Curve (Sky) */}
            <path
              d="M 5 42 L 16 34 L 28 20 L 40 12 L 52 8 L 64 11 L 76 36 L 88 15 L 98 12"
              fill="none"
              stroke="#38bdf8"
              strokeWidth="1.2"
            />

            {/* Data points */}
            {hourlyData.map((d, i) => {
              const x = 5 + (i / (hourlyData.length - 1)) * 93;
              return (
                <g key={i}>
                  <circle cx={x} cy={50 - (d.moves / 100) * 45} r="1.2" fill="#38bdf8" />
                  <circle cx={x} cy={50 - (d.avgSoc / 100) * 45} r="1.2" fill="#10b981" />
                </g>
              );
            })}
          </svg>

          {/* Time axis */}
          <div className="flex justify-between text-[10px] font-mono text-slate-500 pt-2 border-t border-slate-800">
            {hourlyData.map((d) => (
              <span key={d.hour}>{d.hour}</span>
            ))}
          </div>
        </div>
      </div>

      {/* Predictive Maintenance & Subsystem Health Matrix */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
        <h2 className="text-sm font-bold text-white font-sans flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400" />
          Predictive Maintenance & Component Lifespan Analytics
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs font-mono">
          {/* Component 1: Wheel Tread Wear */}
          <div className="bg-slate-950 border border-slate-800 rounded p-4 space-y-2">
            <div className="flex justify-between text-slate-400">
              <span>DRIVE TIRE TREAD WEAR</span>
              <span className="text-emerald-400">NOMINAL</span>
            </div>
            <div className="text-lg font-bold text-white">92.4% <span className="text-xs text-slate-400 font-normal">life left</span></div>
            <div className="w-full bg-slate-800 rounded-full h-1.5">
              <div className="bg-emerald-500 h-1.5 rounded-full" style={{ width: '92.4%' }} />
            </div>
            <div className="text-[11px] text-slate-500">Service in ~1,840 operating hours</div>
          </div>

          {/* Component 2: Battery Cycles */}
          <div className="bg-slate-950 border border-slate-800 rounded p-4 space-y-2">
            <div className="flex justify-between text-slate-400">
              <span>LFP BATTERY CYCLES</span>
              <span className="text-emerald-400">97.8% SOH</span>
            </div>
            <div className="text-lg font-bold text-white">412 / 3,000 <span className="text-xs text-slate-400 font-normal">cycles</span></div>
            <div className="w-full bg-slate-800 rounded-full h-1.5">
              <div className="bg-emerald-500 h-1.5 rounded-full" style={{ width: `${(412/3000)*100}%` }} />
            </div>
            <div className="text-[11px] text-slate-500">Degradation: 0.007% per 100 kWh</div>
          </div>

          {/* Component 3: LiDAR Optical Transmission */}
          <div className="bg-slate-950 border border-slate-800 rounded p-4 space-y-2">
            <div className="flex justify-between text-slate-400">
              <span>LIDAR OPTICAL CLARITY</span>
              <span className="text-amber-400">WARNING</span>
            </div>
            <div className="text-lg font-bold text-amber-400">86.1% <span className="text-xs text-slate-400 font-normal">transmission</span></div>
            <div className="w-full bg-slate-800 rounded-full h-1.5">
              <div className="bg-amber-500 h-1.5 rounded-full" style={{ width: '86.1%' }} />
            </div>
            <div className="text-[11px] text-amber-300/80">AMR-107 lens cleaning advisory</div>
          </div>

          {/* Component 4: Motor Inverter Temperature */}
          <div className="bg-slate-950 border border-slate-800 rounded p-4 space-y-2">
            <div className="flex justify-between text-slate-400">
              <span>INVERTER THERMALS</span>
              <span className="text-emerald-400">STABLE</span>
            </div>
            <div className="text-lg font-bold text-white">38.4°C <span className="text-xs text-slate-400 font-normal">avg peak</span></div>
            <div className="w-full bg-slate-800 rounded-full h-1.5">
              <div className="bg-emerald-500 h-1.5 rounded-full" style={{ width: '48%' }} />
            </div>
            <div className="text-[11px] text-slate-500">Heatsink margin: +36.6°C to cutoff</div>
          </div>
        </div>
      </div>
    </div>
  );
};

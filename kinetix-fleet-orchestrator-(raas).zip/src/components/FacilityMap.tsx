import React, { useState } from 'react';
import {
  AmrRobot,
  WarehouseZone,
  Obstacle,
  Task,
} from '../types/robotics';
import {
  Layers,
  MapPin,
  AlertTriangle,
  RotateCcw,
  Zap,
  Radio,
  Eye,
  Crosshair,
  Truck,
  PlusCircle,
  XCircle,
} from 'lucide-react';

interface FacilityMapProps {
  robots: AmrRobot[];
  zones: WarehouseZone[];
  obstacles: Obstacle[];
  tasks: Task[];
  selectedRobotId: string | null;
  onSelectRobot: (robotId: string | null) => void;
  onAddObstacle: (x: number, y: number) => void;
  onClearObstacles: () => void;
  facilityEStop: boolean;
}

export const FacilityMap: React.FC<FacilityMapProps> = ({
  robots,
  zones,
  obstacles,
  tasks,
  selectedRobotId,
  onSelectRobot,
  onAddObstacle,
  onClearObstacles,
  facilityEStop,
}) => {
  const [showPaths, setShowPaths] = useState(true);
  const [showBays, setShowBays] = useState(true);
  const [showGrid, setShowGrid] = useState(true);
  const [isPlacingObstacle, setIsPlacingObstacle] = useState(false);
  const [hoveredCoords, setHoveredCoords] = useState<{ x: number; y: number } | null>(null);

  const selectedRobot = robots.find((r) => r.id === selectedRobotId);

  // SVG dimensions
  const viewBoxWidth = 100;
  const viewBoxHeight = 60;

  const handleSvgClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!isPlacingObstacle) return;
    const svg = e.currentTarget;
    const rect = svg.getBoundingClientRect();
    const clickX = ((e.clientX - rect.left) / rect.width) * viewBoxWidth;
    const clickY = ((e.clientY - rect.top) / rect.height) * viewBoxHeight;

    onAddObstacle(Number(clickX.toFixed(1)), Number(clickY.toFixed(1)));
    setIsPlacingObstacle(false);
  };

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    const svg = e.currentTarget;
    const rect = svg.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * viewBoxWidth;
    const y = ((e.clientY - rect.top) / rect.height) * viewBoxHeight;
    setHoveredCoords({ x: Math.round(x * 10) / 10, y: Math.round(y * 10) / 10 });
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-200">
      {/* Map Control Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-2.5 bg-slate-900 border-b border-slate-800 text-xs">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-slate-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-mono text-slate-300">FACILITY 01: FULFILLMENT MATRIX</span>
          </div>
          <span className="text-slate-600">·</span>
          <div className="font-mono text-slate-400 tabular-nums">
            {hoveredCoords ? `COORDS: X=${hoveredCoords.x.toFixed(1)}m, Y=${hoveredCoords.y.toFixed(1)}m` : 'GRID: 100m × 60m'}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Layer toggles */}
          <button
            onClick={() => setShowPaths(!showPaths)}
            className={`px-2.5 py-1 rounded border transition-colors flex items-center gap-1.5 ${
              showPaths ? 'bg-slate-800 text-amber-300 border-slate-700' : 'bg-slate-950 text-slate-500 border-slate-800'
            }`}
          >
            <Radio className="w-3 h-3" />
            <span>Path Trails</span>
          </button>

          <button
            onClick={() => setShowBays(!showBays)}
            className={`px-2.5 py-1 rounded border transition-colors flex items-center gap-1.5 ${
              showBays ? 'bg-slate-800 text-amber-300 border-slate-700' : 'bg-slate-950 text-slate-500 border-slate-800'
            }`}
          >
            <MapPin className="w-3 h-3" />
            <span>Bay Labels</span>
          </button>

          <button
            onClick={() => setShowGrid(!showGrid)}
            className={`px-2.5 py-1 rounded border transition-colors flex items-center gap-1.5 ${
              showGrid ? 'bg-slate-800 text-amber-300 border-slate-700' : 'bg-slate-950 text-slate-500 border-slate-800'
            }`}
          >
            <Layers className="w-3 h-3" />
            <span>Aisle Grid</span>
          </button>

          {/* Dynamic Obstacle Placement */}
          <button
            onClick={() => setIsPlacingObstacle(!isPlacingObstacle)}
            className={`px-2.5 py-1 rounded border transition-colors flex items-center gap-1.5 ${
              isPlacingObstacle
                ? 'bg-amber-500 text-slate-950 font-semibold border-amber-400'
                : 'bg-slate-800 hover:bg-slate-700 text-amber-300 border-slate-700'
            }`}
          >
            <PlusCircle className="w-3 h-3" />
            <span>{isPlacingObstacle ? 'Click Map to Place' : 'Inject Obstacle'}</span>
          </button>

          {obstacles.length > 0 && (
            <button
              onClick={onClearObstacles}
              className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 border border-slate-700 flex items-center gap-1"
              title="Clear simulated obstacles"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Clear ({obstacles.length})</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Interactive SVG Map */}
      <div className="relative flex-1 bg-slate-950 overflow-hidden flex items-center justify-center p-4">
        {/* Global E-Stop Banner overlay if activated */}
        {facilityEStop && (
          <div className="absolute top-6 left-1/2 -translate-x-1/2 z-20 px-6 py-2 bg-rose-950/90 border border-rose-500 text-rose-200 rounded shadow-xl flex items-center gap-3 backdrop-blur animate-pulse">
            <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
            <div>
              <div className="font-bold text-xs uppercase tracking-wider font-mono">GLOBAL FACILITY E-STOP ACTIVE</div>
              <div className="text-xs text-rose-300">All robotic propulsion halted. Interlocks engaged.</div>
            </div>
          </div>
        )}

        <svg
          viewBox={`0 0 ${viewBoxWidth} ${viewBoxHeight}`}
          className={`w-full h-full max-h-[80vh] border border-slate-800/80 rounded-lg shadow-2xl bg-[#070b13] select-none ${
            isPlacingObstacle ? 'cursor-crosshair' : 'cursor-default'
          }`}
          onClick={handleSvgClick}
          onMouseMove={handleMouseMove}
        >
          {/* Defs for patterns and glow filters */}
          <defs>
            {/* Grid Pattern */}
            <pattern id="facilityGrid" width="4" height="4" patternUnits="userSpaceOnUse">
              <path d="M 4 0 L 0 0 0 4" fill="none" stroke="#172033" strokeWidth="0.1" />
            </pattern>
            {/* Hazard Stripe Pattern for Keep-Out / Obstacles */}
            <pattern id="hazardStripe" width="2" height="2" patternTransform="rotate(45 0 0)" patternUnits="userSpaceOnUse">
              <line x1="0" y1="0" x2="0" y2="2" stroke="#e11d48" strokeWidth="0.6" strokeOpacity="0.4" />
            </pattern>
            {/* Racks shelf pattern */}
            <pattern id="rackPattern" width="2" height="2" patternUnits="userSpaceOnUse">
              <rect width="2" height="2" fill="#0f172a" />
              <rect x="0.2" y="0.2" width="1.6" height="1.6" fill="#1e293b" rx="0.2" />
            </pattern>
            {/* Charging station striped glow */}
            <linearGradient id="chargeGlow" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#059669" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#047857" stopOpacity="0.08" />
            </linearGradient>
          </defs>

          {/* Background Grid */}
          {showGrid && <rect width={viewBoxWidth} height={viewBoxHeight} fill="url(#facilityGrid)" />}

          {/* Major High-Speed Corridors (Visual Floor Striping) */}
          <g opacity="0.35">
            {/* North corridor y=10 */}
            <line x1="16" y1="10" x2="84" y2="10" stroke="#38bdf8" strokeWidth="0.8" strokeDasharray="1.5 1.5" />
            {/* Mid corridor y=30 */}
            <line x1="16" y1="30" x2="84" y2="30" stroke="#38bdf8" strokeWidth="0.8" strokeDasharray="1.5 1.5" />
            {/* South corridor y=46 */}
            <line x1="16" y1="46" x2="84" y2="46" stroke="#38bdf8" strokeWidth="0.8" strokeDasharray="1.5 1.5" />
            {/* Vertical transit arteries */}
            <line x1="18" y1="8" x2="18" y2="52" stroke="#38bdf8" strokeWidth="0.8" strokeDasharray="1.5 1.5" />
            <line x1="48" y1="8" x2="48" y2="52" stroke="#38bdf8" strokeWidth="0.8" strokeDasharray="1.5 1.5" />
            <line x1="78" y1="8" x2="78" y2="52" stroke="#38bdf8" strokeWidth="0.8" strokeDasharray="1.5 1.5" />
          </g>

          {/* Zones */}
          {zones.map((zone) => {
            const { x, y, width, height } = zone.bounds;
            return (
              <g key={zone.id}>
                {/* Zone Area Box */}
                <rect
                  x={x}
                  y={y}
                  width={width}
                  height={height}
                  fill={
                    zone.type === 'charging'
                      ? 'url(#chargeGlow)'
                      : zone.type === 'racks'
                      ? 'url(#rackPattern)'
                      : `${zone.color}15`
                  }
                  stroke={zone.color}
                  strokeWidth="0.25"
                  strokeDasharray={zone.type === 'racks' ? 'none' : '1 0.5'}
                  rx="0.6"
                />

                {/* Zone Name Label */}
                <text
                  x={x + 1}
                  y={y + 2.4}
                  fill={zone.color}
                  fontSize="1.3"
                  fontWeight="600"
                  fontFamily="JetBrains Mono, monospace"
                  className="pointer-events-none uppercase tracking-wider"
                >
                  {zone.name}
                </text>

                {/* Bays & Specific Pick/Drop Slots */}
                {showBays &&
                  zone.bays?.map((bay, bIdx) => (
                    <g key={bIdx} className="pointer-events-none">
                      <circle cx={bay.x} cy={bay.y} r="0.6" fill={zone.color} opacity="0.6" />
                      <text
                        x={bay.x + 0.9}
                        y={bay.y + 0.4}
                        fill="#94a3b8"
                        fontSize="0.9"
                        fontFamily="JetBrains Mono, monospace"
                      >
                        {bay.name.replace(/High-Density\s/g, '').replace(/MES\sLine\s/g, 'L')}
                      </text>
                    </g>
                  ))}
              </g>
            );
          })}

          {/* Obstacles & Spill Zones */}
          {obstacles.map((obs) => (
            <g key={obs.id}>
              {/* Outer detection cushion */}
              <circle
                cx={obs.x}
                cy={obs.y}
                r={obs.radius + 1.2}
                fill="none"
                stroke="#f43f5e"
                strokeWidth="0.2"
                strokeDasharray="0.8 0.5"
                opacity="0.8"
              />
              {/* Hazard Core */}
              <circle cx={obs.x} cy={obs.y} r={obs.radius} fill="url(#hazardStripe)" stroke="#e11d48" strokeWidth="0.3" />
              <text
                x={obs.x}
                y={obs.y + 0.4}
                fill="#fda4af"
                fontSize="1.0"
                fontFamily="JetBrains Mono, monospace"
                textAnchor="middle"
                className="font-bold pointer-events-none"
              >
                OBSTACLE
              </text>
            </g>
          ))}

          {/* AMR Path Trails and Target Waypoints */}
          {showPaths &&
            robots.map((robot) => {
              if (robot.path.length === 0 || robot.status === 'idle' || robot.status === 'charging') return null;
              const isSelected = robot.id === selectedRobotId;
              const pathString = robot.path.reduce((acc, wp, idx) => {
                return idx === 0 ? `M ${wp.x} ${wp.y}` : `${acc} L ${wp.x} ${wp.y}`;
              }, '');

              return (
                <g key={`path-${robot.id}`} className="pointer-events-none">
                  {/* Waypoint connecting line */}
                  <path
                    d={pathString}
                    fill="none"
                    stroke={isSelected ? '#38bdf8' : '#fbbf24'}
                    strokeWidth={isSelected ? '0.5' : '0.25'}
                    strokeDasharray={isSelected ? '1 0.5' : '0.8 0.6'}
                    opacity={isSelected ? 1.0 : 0.6}
                  />

                  {/* Waypoint target circles */}
                  {robot.path.map((wp, wIdx) => (
                    <circle
                      key={wIdx}
                      cx={wp.x}
                      cy={wp.y}
                      r={wIdx === robot.path.length - 1 ? '0.8' : '0.4'}
                      fill={wIdx === robot.path.length - 1 ? '#ef4444' : '#fbbf24'}
                      opacity={0.8}
                    />
                  ))}
                </g>
              );
            })}

          {/* AMR Robots */}
          {robots.map((robot) => {
            const isSelected = robot.id === selectedRobotId;
            const headingRad = (robot.heading * Math.PI) / 180;
            const size = robot.model.includes('Titan') ? 2.4 : 1.8;

            // Status color mappings
            let statusColor = '#38bdf8'; // Blue for in_transit
            if (robot.status === 'idle') statusColor = '#94a3b8'; // Slate
            if (robot.status === 'charging') statusColor = '#10b981'; // Green
            if (robot.status === 'blocked') statusColor = '#f59e0b'; // Amber
            if (robot.status === 'e_stop' || facilityEStop) statusColor = '#ef4444'; // Red

            return (
              <g
                key={robot.id}
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectRobot(robot.id === selectedRobotId ? null : robot.id);
                }}
                className="cursor-pointer transition-transform hover:opacity-90"
              >
                {/* Selection halo */}
                {isSelected && (
                  <circle
                    cx={robot.position.x}
                    cy={robot.position.y}
                    r={size + 1.2}
                    fill="none"
                    stroke="#38bdf8"
                    strokeWidth="0.3"
                    strokeDasharray="1 0.5"
                    className="animate-spin origin-center"
                    style={{
                      transformOrigin: `${robot.position.x}px ${robot.position.y}px`,
                    }}
                  />
                )}

                {/* Simulated LiDAR FOV / Scan fan */}
                {isSelected && robot.status === 'in_transit' && (
                  <path
                    d={`M ${robot.position.x} ${robot.position.y} L ${
                      robot.position.x + Math.cos(headingRad - 0.4) * (robot.lidarClearance || 5)
                    } ${robot.position.y + Math.sin(headingRad - 0.4) * (robot.lidarClearance || 5)} A ${
                      robot.lidarClearance || 5
                    } ${robot.lidarClearance || 5} 0 0 1 ${
                      robot.position.x + Math.cos(headingRad + 0.4) * (robot.lidarClearance || 5)
                    } ${robot.position.y + Math.sin(headingRad + 0.4) * (robot.lidarClearance || 5)} Z`}
                    fill="#38bdf8"
                    fillOpacity="0.12"
                    stroke="#38bdf8"
                    strokeWidth="0.1"
                    strokeDasharray="0.5 0.5"
                  />
                )}

                {/* Robot Chassis Base */}
                <g transform={`rotate(${robot.heading}, ${robot.position.x}, ${robot.position.y})`}>
                  <rect
                    x={robot.position.x - size / 2}
                    y={robot.position.y - size / 2}
                    width={size}
                    height={size}
                    rx="0.4"
                    fill={isSelected ? '#1e293b' : '#0f172a'}
                    stroke={statusColor}
                    strokeWidth={isSelected ? '0.4' : '0.25'}
                  />

                  {/* Directional front notch / LiDAR puck */}
                  <circle
                    cx={robot.position.x + size / 2 - 0.3}
                    cy={robot.position.y}
                    r="0.35"
                    fill={statusColor}
                  />

                  {/* Left / Right wheel tracks */}
                  <rect
                    x={robot.position.x - size / 2 + 0.2}
                    y={robot.position.y - size / 2 - 0.2}
                    width={size - 0.4}
                    height="0.2"
                    fill="#334155"
                  />
                  <rect
                    x={robot.position.x - size / 2 + 0.2}
                    y={robot.position.y + size / 2}
                    width={size - 0.4}
                    height="0.2"
                    fill="#334155"
                  />

                  {/* Payload box indicator if carrying weight */}
                  {robot.payloadKg > 0 && (
                    <rect
                      x={robot.position.x - size / 2 + 0.4}
                      y={robot.position.y - size / 2 + 0.4}
                      width={size - 0.8}
                      height={size - 0.8}
                      fill="#eab308"
                      opacity="0.8"
                      rx="0.2"
                    />
                  )}
                </g>

                {/* Robot Callsign & Speed text label */}
                <text
                  x={robot.position.x}
                  y={robot.position.y - size / 2 - 0.6}
                  fill={isSelected ? '#38bdf8' : '#f8fafc'}
                  fontSize="1.1"
                  fontWeight="bold"
                  fontFamily="JetBrains Mono, monospace"
                  textAnchor="middle"
                  className="pointer-events-none drop-shadow-md"
                >
                  {robot.callsign}
                </text>

                {/* Battery SOC Pill */}
                <rect
                  x={robot.position.x - 1.2}
                  y={robot.position.y + size / 2 + 0.5}
                  width="2.4"
                  height="0.5"
                  fill="#1e293b"
                  rx="0.2"
                />
                <rect
                  x={robot.position.x - 1.2}
                  y={robot.position.y + size / 2 + 0.5}
                  width={`${(robot.batterySoc / 100) * 2.4}`}
                  height="0.5"
                  fill={robot.batterySoc > 40 ? '#10b981' : robot.batterySoc > 20 ? '#f59e0b' : '#ef4444'}
                  rx="0.2"
                />
              </g>
            );
          })}
        </svg>

        {/* Quick Fleet Quick-Stats Overlay Card */}
        <div className="absolute bottom-6 left-6 z-10 bg-slate-900/90 border border-slate-800 rounded-lg p-3 backdrop-blur text-xs shadow-xl hidden md:flex items-center gap-4 font-mono">
          <div className="flex items-center gap-2">
            <span className="text-slate-400">FLEET:</span>
            <span className="text-white font-bold">{robots.length} AMRs</span>
          </div>
          <span className="text-slate-700">|</span>
          <div className="flex items-center gap-1.5 text-sky-400">
            <span className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-pulse" />
            <span>TRANSIT: {robots.filter((r) => r.status === 'in_transit').length}</span>
          </div>
          <div className="flex items-center gap-1.5 text-emerald-400">
            <Zap className="w-3 h-3" />
            <span>CHARGE: {robots.filter((r) => r.status === 'charging').length}</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-400">
            <span>IDLE: {robots.filter((r) => r.status === 'idle').length}</span>
          </div>
          {obstacles.length > 0 && (
            <div className="flex items-center gap-1.5 text-amber-400">
              <AlertTriangle className="w-3 h-3" />
              <span>OBSTACLES: {obstacles.length}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

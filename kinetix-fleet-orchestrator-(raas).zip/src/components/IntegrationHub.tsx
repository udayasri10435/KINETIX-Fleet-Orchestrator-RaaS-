import React, { useState } from 'react';
import {
  WmsOrder,
  MesWorkOrder,
  Task,
  AmrRobot,
} from '../types/robotics';
import {
  Workflow,
  Boxes,
  Cpu,
  RefreshCw,
  ArrowRight,
  CheckCircle,
  AlertTriangle,
  Radio,
  FileCode,
  Copy,
  Check,
  Pause,
  Play,
  Share2,
} from 'lucide-react';

interface IntegrationHubProps {
  wmsOrders: WmsOrder[];
  mesOrders: MesWorkOrder[];
  onSyncWms: () => void;
  onSimulateMesConsumption: () => void;
  onConvertWmsOrderToTask: (orderId: string) => void;
  onReplenishMesLine: (workOrderId: string) => void;
  robots: AmrRobot[];
}

export const IntegrationHub: React.FC<IntegrationHubProps> = ({
  wmsOrders,
  mesOrders,
  onSyncWms,
  onSimulateMesConsumption,
  onConvertWmsOrderToTask,
  onReplenishMesLine,
  robots,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'topology' | 'wms' | 'mes' | 'vda_bus'>('topology');
  const [isBusStreaming, setIsBusStreaming] = useState(true);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  // Simulated live protocol event stream
  const [protocolLogs] = useState([
    {
      time: '10:28:12.402',
      source: 'WMS (SAP EWM)',
      topic: 'vda5050/order/inbound_putaway',
      level: 'INFO',
      payload: {
        orderId: 'WMS-7821',
        action: 'PUTAWAY_WAVE_DISPATCH',
        sku: 'SKU-DRIVE-TRAIN-88',
        assignedPalletId: 'PLT-8840',
        dock: 'D-02',
      },
    },
    {
      time: '10:28:05.120',
      source: 'KINETIX FLEET CORE',
      topic: 'vda5050/state/AMR-101',
      level: 'INFO',
      payload: {
        headerId: 99421,
        serialNumber: 'AMR-101',
        batteryState: { batteryCharge: 84.0, charging: false },
        driving: true,
        lastNodeId: 'node_corridor_w18',
      },
    },
    {
      time: '10:27:48.889',
      source: 'MES (Siemens Opcenter)',
      topic: 'mes/assembly/line2/buffer_alert',
      level: 'WARN',
      payload: {
        workOrderId: 'MES-WO-109',
        bufferRemaining: '18%',
        threshold: '25%',
        requiredPart: 'SKU-HARNESS-J60',
        urgency: 'STARVATION_IMMINENT',
      },
    },
    {
      time: '10:27:10.510',
      source: 'KINETIX FLEET CORE',
      topic: 'vda5050/order/dispatch/AMR-103',
      level: 'INFO',
      payload: {
        orderId: 'ORD-TSK-9403',
        priority: 1,
        dest: 'MES_LINE_2_POWER_UNIT',
        etaMinutes: 2.4,
      },
    },
  ]);

  const copyLogPayload = (idx: number, payload: unknown) => {
    navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 p-6 space-y-6 overflow-y-auto">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white font-sans">
            WMS & MES Integration Gateway
          </h1>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Bi-directional synchronization layer bridging Warehouse & Manufacturing Execution systems with AMR fleets
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onSyncWms}
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-sky-400 border border-slate-700 rounded text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Sync WMS Wave</span>
          </button>
          <button
            onClick={onSimulateMesConsumption}
            className="px-3 py-2 bg-purple-950/80 hover:bg-purple-900 border border-purple-700/60 text-purple-300 rounded text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>Simulate MES Line Draw</span>
          </button>
        </div>
      </div>

      {/* Architecture Topology Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5">
        <div className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-4 flex items-center justify-between">
          <span className="flex items-center gap-2">
            <Share2 className="w-4 h-4 text-amber-400" />
            LIVE PROTOCOL TOPOLOGY & DATA BRIDGES
          </span>
          <span className="text-emerald-400 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            VDA 5050 v2.0 MQTT BROKER ONLINE (14ms)
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
          {/* Node 1: WMS */}
          <div className="bg-slate-950 border border-slate-800 rounded p-4 relative">
            <div className="flex items-center justify-between text-sky-400 font-bold mb-2">
              <span className="flex items-center gap-1.5">
                <Boxes className="w-4 h-4" />
                ENTERPRISE WMS
              </span>
              <span className="text-[10px] bg-sky-950 text-sky-300 border border-sky-800 px-1.5 py-0.5 rounded">
                REST / Webhooks
              </span>
            </div>
            <p className="text-slate-400 text-[11px] mb-3 font-sans">
              Manages purchase orders, picking waves, pallet putaway, and dock scheduling.
            </p>
            <div className="space-y-1 text-slate-400 text-[11px]">
              <div className="flex justify-between"><span>Pending Waves:</span><span className="text-white font-bold">{wmsOrders.filter(o => o.status === 'processing').length} active</span></div>
              <div className="flex justify-between"><span>Last Sync:</span><span className="text-slate-300">10:26:40</span></div>
            </div>
          </div>

          {/* Node 2: KINETIX FLEET MANAGER (CENTER) */}
          <div className="bg-slate-950 border-2 border-amber-500/60 rounded p-4 relative shadow-lg shadow-amber-500/5">
            <div className="flex items-center justify-between text-amber-400 font-bold mb-2">
              <span className="flex items-center gap-1.5">
                <Workflow className="w-4 h-4" />
                KINETIX ORCHESTRATOR
              </span>
              <span className="text-[10px] bg-amber-950 text-amber-300 border border-amber-800 px-1.5 py-0.5 rounded">
                Core Engine
              </span>
            </div>
            <p className="text-slate-400 text-[11px] mb-3 font-sans">
              VDA 5050 task assignment, spatial traffic control, dynamic kinematic routing.
            </p>
            <div className="space-y-1 text-slate-400 text-[11px]">
              <div className="flex justify-between"><span>Connected AMRs:</span><span className="text-amber-400 font-bold">{robots.length} Units</span></div>
              <div className="flex justify-between"><span>Active Missions:</span><span className="text-white font-bold">{robots.filter(r => r.status === 'in_transit').length} In-Transit</span></div>
            </div>
          </div>

          {/* Node 3: MES */}
          <div className="bg-slate-950 border border-slate-800 rounded p-4 relative">
            <div className="flex items-center justify-between text-purple-400 font-bold mb-2">
              <span className="flex items-center gap-1.5">
                <Cpu className="w-4 h-4" />
                FACTORY FLOOR MES
              </span>
              <span className="text-[10px] bg-purple-950 text-purple-300 border border-purple-800 px-1.5 py-0.5 rounded">
                OPC-UA / MQTT
              </span>
            </div>
            <p className="text-slate-400 text-[11px] mb-3 font-sans">
              Line buffer sensors, WIP component replenishment, and takt time synchronization.
            </p>
            <div className="space-y-1 text-slate-400 text-[11px]">
              <div className="flex justify-between"><span>Assembly Lines:</span><span className="text-purple-300 font-bold">{mesOrders.length} Cells</span></div>
              <div className="flex justify-between"><span>Buffer Starved:</span><span className="text-rose-400 font-bold">{mesOrders.filter(m => m.status === 'starved').length} alert</span></div>
            </div>
          </div>
        </div>
      </div>

      {/* Sub Tabs */}
      <div className="flex items-center gap-1 border-b border-slate-800 text-xs font-medium">
        <button
          onClick={() => setActiveSubTab('wms')}
          className={`py-2 px-3 border-b-2 transition-colors ${
            activeSubTab === 'wms'
              ? 'border-sky-400 text-sky-400 font-semibold'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          WMS Orders & Wave Manifests ({wmsOrders.length})
        </button>
        <button
          onClick={() => setActiveSubTab('mes')}
          className={`py-2 px-3 border-b-2 transition-colors ${
            activeSubTab === 'mes'
              ? 'border-purple-400 text-purple-400 font-semibold'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          MES Assembly Line Buffers ({mesOrders.length})
        </button>
        <button
          onClick={() => setActiveSubTab('vda_bus')}
          className={`py-2 px-3 border-b-2 transition-colors ${
            activeSubTab === 'vda_bus'
              ? 'border-amber-400 text-amber-400 font-semibold'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Live VDA 5050 & Event Stream
        </button>
      </div>

      {/* Sub Tab Content */}
      {activeSubTab === 'wms' && (
        <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-mono">
              <tr>
                <th className="py-3 px-4">ORDER ID / TYPE</th>
                <th className="py-3 px-4">CUSTOMER / ACCOUNT</th>
                <th className="py-3 px-4">WAVE ASSIGNMENT</th>
                <th className="py-3 px-4">PAYLOAD / WEIGHT</th>
                <th className="py-3 px-4">WMS STATUS</th>
                <th className="py-3 px-4 text-right">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {wmsOrders.map((order) => (
                <tr key={order.orderId} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4 font-mono">
                    <div className="font-bold text-slate-200">{order.orderId}</div>
                    <div className="text-[11px] text-slate-400 capitalize">{order.type.replace('_', ' ')}</div>
                  </td>
                  <td className="py-3 px-4 text-slate-300 font-medium">
                    {order.customer}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-400">
                    {order.assignedWave}
                  </td>
                  <td className="py-3 px-4 font-mono">
                    <span className="text-white font-bold">{order.totalWeightKg} kg</span>
                    <span className="text-slate-500 text-[11px]"> ({order.lineItemsCount} items)</span>
                  </td>
                  <td className="py-3 px-4 font-mono">
                    <span
                      className={`px-2 py-0.5 rounded text-[11px] uppercase ${
                        order.status === 'processing'
                          ? 'bg-sky-950 text-sky-400 border border-sky-800'
                          : order.status === 'shipped'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : 'bg-slate-800 text-slate-400 border border-slate-700'
                      }`}
                    >
                      {order.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    {order.status === 'pending' ? (
                      <button
                        onClick={() => onConvertWmsOrderToTask(order.orderId)}
                        className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-[11px] font-mono transition-colors shadow-sm"
                      >
                        Dispatch AMR
                      </button>
                    ) : (
                      <span className="text-slate-500 text-[11px] font-mono">Tasks Active</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeSubTab === 'mes' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {mesOrders.map((mes) => {
            const isStarved = mes.bufferStockLevel <= mes.minBufferThreshold;

            return (
              <div
                key={mes.workOrderId}
                className={`bg-slate-900 border rounded-lg p-5 space-y-4 ${
                  isStarved ? 'border-rose-700/80 bg-rose-950/10' : 'border-slate-800'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-purple-400 font-bold">{mes.workOrderId}</span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                      isStarved
                        ? 'bg-rose-900/60 text-rose-300 border border-rose-700 animate-pulse'
                        : mes.status === 'replenishing'
                        ? 'bg-sky-950 text-sky-400 border border-sky-800'
                        : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                    }`}
                  >
                    {isStarved ? 'STARVATION WARNING' : mes.status}
                  </span>
                </div>

                <div>
                  <h3 className="font-bold text-white text-sm">{mes.assemblyLine}</h3>
                  <div className="text-xs text-slate-400 font-mono mt-0.5">{mes.productPart}</div>
                </div>

                {/* Buffer gauge */}
                <div className="space-y-1.5 text-xs font-mono">
                  <div className="flex justify-between">
                    <span className="text-slate-400">BUFFER INVENTORY:</span>
                    <span className={isStarved ? 'text-rose-400 font-bold' : 'text-slate-200'}>
                      {mes.bufferStockLevel}% (Min: {mes.minBufferThreshold}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-2 rounded-full transition-all ${
                        isStarved ? 'bg-rose-500' : 'bg-purple-500'
                      }`}
                      style={{ width: `${mes.bufferStockLevel}%` }}
                    />
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Takt requirement: {mes.requiredPartsPerHr} parts/hr · Lot: {mes.batchLot}
                  </div>
                </div>

                {/* Replenish Action */}
                <button
                  onClick={() => onReplenishMesLine(mes.workOrderId)}
                  className={`w-full py-2 rounded text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition-colors ${
                    isStarved
                      ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-sm'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                  }`}
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>{isStarved ? 'Trigger Emergency Replenishment' : 'Call Parts Shuttle'}</span>
                </button>
              </div>
            );
          })}
        </div>
      )}

      {activeSubTab === 'vda_bus' && (
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3 font-mono">
          <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
              <span className="font-bold text-slate-200">MQTT BROKER TOPIC STREAM: /vda5050/v2/#</span>
            </div>
            <button
              onClick={() => setIsBusStreaming(!isBusStreaming)}
              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] flex items-center gap-1"
            >
              {isBusStreaming ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
              <span>{isBusStreaming ? 'Pause Stream' : 'Resume'}</span>
            </button>
          </div>

          <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
            {protocolLogs.map((log, idx) => (
              <div key={idx} className="bg-slate-950 border border-slate-800 rounded p-3 text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-slate-500">{log.time}</span>
                    <span className="text-amber-400 font-bold">{log.source}</span>
                    <span className="text-slate-600">→</span>
                    <span className="text-sky-300">{log.topic}</span>
                  </div>
                  <button
                    onClick={() => copyLogPayload(idx, log.payload)}
                    className="text-slate-500 hover:text-amber-400 transition-colors"
                    title="Copy payload"
                  >
                    {copiedIndex === idx ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <pre className="text-[11px] text-slate-300 bg-slate-900/60 p-2 rounded overflow-x-auto">
                  {JSON.stringify(log.payload, null, 2)}
                </pre>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

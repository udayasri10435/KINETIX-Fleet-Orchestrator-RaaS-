import React from 'react';
import {
  ShieldAlert,
  Play,
  Pause,
  FastForward,
  Sparkles,
} from 'lucide-react';

export type NavTab = 'digital_twin' | 'missions' | 'integration' | 'telemetry' | 'raas';

interface HeaderProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  isSimRunning: boolean;
  setIsSimRunning: React.Dispatch<React.SetStateAction<boolean>>;
  simSpeed: number;
  setSimSpeed: (speed: number) => void;
  facilityEStop: boolean;
  onTriggerGlobalEStop: () => void;
  onResetGlobalEStop: () => void;
  autoDispatchEnabled: boolean;
  setAutoDispatchEnabled: React.Dispatch<React.SetStateAction<boolean>>;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  isSimRunning,
  setIsSimRunning,
  simSpeed,
  setSimSpeed,
  facilityEStop,
  onTriggerGlobalEStop,
  onResetGlobalEStop,
  autoDispatchEnabled,
  setAutoDispatchEnabled,
}) => {
  return (
    <header className="flex items-center justify-between px-6 py-3.5 bg-slate-900/90 backdrop-blur border-b border-slate-800 text-slate-100 z-30 sticky top-0">
      {/* Zone 1: Brand Wordmark (Single Text Element) */}
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center font-bold text-slate-950 font-mono tracking-tighter text-base shadow-sm">
          KX
        </div>
        <span className="text-base font-bold tracking-tight text-white font-sans whitespace-nowrap">
          KINETIX Fleet Orchestrator
        </span>
      </div>

      {/* Zone 2: Navigation Links (Clean single-line text tabs) */}
      <nav className="hidden lg:flex items-center gap-1 bg-slate-950/60 p-1 rounded-lg border border-slate-800/80">
        <button
          onClick={() => setActiveTab('digital_twin')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'digital_twin'
              ? 'bg-slate-800 text-amber-400 shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Digital Twin & Map
        </button>
        <button
          onClick={() => setActiveTab('missions')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'missions'
              ? 'bg-slate-800 text-amber-400 shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Missions & Task Allocation
        </button>
        <button
          onClick={() => setActiveTab('integration')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'integration'
              ? 'bg-slate-800 text-amber-400 shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          WMS & MES Integration
        </button>
        <button
          onClick={() => setActiveTab('telemetry')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'telemetry'
              ? 'bg-slate-800 text-amber-400 shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Telemetry & Diagnostics
        </button>
        <button
          onClick={() => setActiveTab('raas')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'raas'
              ? 'bg-slate-800 text-amber-400 shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          RaaS Economics & SLA
        </button>
      </nav>

      {/* Zone 3: Primary Action Controls */}
      <div className="flex items-center gap-2.5">
        {/* Auto Dispatch Toggle */}
        <button
          onClick={() => setAutoDispatchEnabled((prev) => !prev)}
          title="Toggle automated cost-matrix task allocation"
          className={`px-2.5 py-1.5 text-xs font-medium rounded flex items-center gap-1.5 border transition-all ${
            autoDispatchEnabled
              ? 'bg-emerald-950/40 text-emerald-300 border-emerald-700/60'
              : 'bg-slate-800/80 text-slate-400 border-slate-700'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Auto-Dispatch</span>
          <span className={`w-1.5 h-1.5 rounded-full ${autoDispatchEnabled ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'}`} />
        </button>

        {/* Simulation Speed & Controls */}
        <div className="flex items-center bg-slate-950/70 border border-slate-800 rounded p-0.5">
          <button
            onClick={() => setIsSimRunning((prev) => !prev)}
            className="p-1.5 hover:bg-slate-800 text-slate-300 hover:text-white rounded transition-colors"
            title={isSimRunning ? 'Pause Simulation' : 'Run Simulation'}
          >
            {isSimRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 text-emerald-400" />}
          </button>
          <button
            onClick={() => {
              const speeds = [1, 2, 5];
              const nextIdx = (speeds.indexOf(simSpeed) + 1) % speeds.length;
              setSimSpeed(speeds[nextIdx]);
            }}
            className="px-2 py-1 text-xs font-mono font-medium text-slate-300 hover:text-white hover:bg-slate-800 rounded flex items-center gap-1 transition-colors"
            title="Cycle simulation speed"
          >
            <FastForward className="w-3 h-3 text-amber-400" />
            <span>{simSpeed}x</span>
          </button>
        </div>

        {/* Global Facility E-Stop Button */}
        {facilityEStop ? (
          <button
            onClick={onResetGlobalEStop}
            className="px-3 py-1.5 text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white rounded flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Reset E-Stop</span>
          </button>
        ) : (
          <button
            onClick={onTriggerGlobalEStop}
            className="px-3 py-1.5 text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white rounded flex items-center gap-1.5 transition-colors shadow-sm animate-none hover:shadow-rose-600/30"
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Facility E-Stop</span>
          </button>
        )}
      </div>
    </header>
  );
};

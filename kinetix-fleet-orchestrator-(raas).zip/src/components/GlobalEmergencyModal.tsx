import React, { useState } from 'react';
import {
  ShieldAlert,
  AlertTriangle,
  RotateCcw,
  CheckCircle2,
} from 'lucide-react';
import { AmrRobot } from '../types/robotics';

interface GlobalEmergencyModalProps {
  isOpen: boolean;
  robots: AmrRobot[];
  onConfirmReset: () => void;
  onCancel: () => void;
}

export const GlobalEmergencyModal: React.FC<GlobalEmergencyModalProps> = ({
  isOpen,
  robots,
  onConfirmReset,
  onCancel,
}) => {
  const [operatorInitials, setOperatorInitials] = useState('');
  const [confirmedSafetyClear, setConfirmedSafetyClear] = useState(false);

  if (!isOpen) return null;

  const handleResetSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!confirmedSafetyClear || !operatorInitials.trim()) return;
    onConfirmReset();
    setOperatorInitials('');
    setConfirmedSafetyClear(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-950 border-2 border-rose-600 rounded-xl max-w-lg w-full p-6 shadow-2xl space-y-6 text-slate-100 animate-in fade-in zoom-in-95">
        {/* Warning Header */}
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-rose-600 flex items-center justify-center text-white shrink-0 shadow-lg shadow-rose-600/50 animate-bounce">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-rose-500 font-sans tracking-tight">
              FACILITY SAFETY INTERLOCK ENGAGED
            </h2>
            <p className="text-xs text-slate-400 font-mono">
              Global Emergency Stop triggered (ISO 3691-4 Category 3 PL d compliant)
            </p>
          </div>
        </div>

        {/* Affected Fleet Status */}
        <div className="bg-slate-900 border border-slate-800 rounded p-4 text-xs font-mono space-y-2">
          <div className="flex justify-between text-slate-400">
            <span>AFFECTED PROPULSION DRIVES:</span>
            <span className="text-rose-400 font-bold">{robots.length} AMRs DEAD-HALTED</span>
          </div>
          <div className="flex justify-between text-slate-400">
            <span>ACTIVE BRAKING CURRENT:</span>
            <span className="text-emerald-400 font-bold">ELECTROMECHANICAL BRAKES LOCKED</span>
          </div>
          <div className="flex justify-between text-slate-400">
            <span>COLLISION CLEARANCE:</span>
            <span className="text-slate-200">ALL ZONES SAFE</span>
          </div>
        </div>

        {/* Safety Reset Checklist Form */}
        <form onSubmit={handleResetSubmit} className="space-y-4 text-xs">
          <label className="flex items-start gap-2.5 p-3 bg-slate-900 border border-slate-800 rounded cursor-pointer hover:bg-slate-850">
            <input
              type="checkbox"
              checked={confirmedSafetyClear}
              onChange={(e) => setConfirmedSafetyClear(e.target.checked)}
              className="mt-0.5 accent-rose-600 w-4 h-4 rounded"
            />
            <span className="text-slate-300">
              I verify that all travel corridors, rack aisles, and robotic docking zones are physically clear of obstacles, human personnel, and mechanical pinch hazards.
            </span>
          </label>

          <div>
            <label className="block text-slate-400 font-mono mb-1">
              OPERATOR SAFETY BADGE / INITIALS (AUDIT LOG ENTRY)
            </label>
            <input
              type="text"
              value={operatorInitials}
              onChange={(e) => setOperatorInitials(e.target.value.toUpperCase())}
              placeholder="e.g. OP-8492"
              className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-slate-100 font-mono"
              maxLength={10}
              required
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 bg-slate-850 hover:bg-slate-800 text-slate-300 rounded font-medium transition-colors"
            >
              Keep E-Stop Active
            </button>
            <button
              type="submit"
              disabled={!confirmedSafetyClear || !operatorInitials.trim()}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold rounded font-mono flex items-center gap-1.5 shadow-sm transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Release Interlocks & Resume</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

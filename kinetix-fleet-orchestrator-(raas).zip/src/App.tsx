import React, { useState, useEffect, useRef } from 'react';
import {
  Header,
  NavTab,
} from './components/Header';
import { FacilityMap } from './components/FacilityMap';
import { RobotDetailModal } from './components/RobotDetailModal';
import { MissionPlanner } from './components/MissionPlanner';
import { IntegrationHub } from './components/IntegrationHub';
import { TelemetryAnalytics } from './components/TelemetryAnalytics';
import { RaasEconomics } from './components/RaasEconomics';
import { GlobalEmergencyModal } from './components/GlobalEmergencyModal';

import {
  INITIAL_ROBOTS,
  INITIAL_TASKS,
  INITIAL_ZONES,
  INITIAL_OBSTACLES,
  INITIAL_WMS_ORDERS,
  INITIAL_MES_ORDERS,
  INITIAL_RAAS_METRICS,
} from './data/mockData';

import {
  AmrRobot,
  Task,
  WarehouseZone,
  Obstacle,
  WmsOrder,
  MesWorkOrder,
  RaaSMetrics,
} from './types/robotics';

import {
  updateAmrSimulation,
  autoAllocateTask,
  findWarehousePath,
} from './utils/roboticsEngine';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('digital_twin');
  const [robots, setRobots] = useState<AmrRobot[]>(INITIAL_ROBOTS);
  const [tasks, setTasks] = useState<Task[]>(INITIAL_TASKS);
  const [zones] = useState<WarehouseZone[]>(INITIAL_ZONES);
  const [obstacles, setObstacles] = useState<Obstacle[]>(INITIAL_OBSTACLES);
  const [wmsOrders, setWmsOrders] = useState<WmsOrder[]>(INITIAL_WMS_ORDERS);
  const [mesOrders, setMesOrders] = useState<MesWorkOrder[]>(INITIAL_MES_ORDERS);
  const [metrics, setMetrics] = useState<RaaSMetrics>(INITIAL_RAAS_METRICS);

  // Simulation controls
  const [isSimRunning, setIsSimRunning] = useState(true);
  const [simSpeed, setSimSpeed] = useState(1);
  const [autoDispatchEnabled, setAutoDispatchEnabled] = useState(true);
  const [selectedRobotId, setSelectedRobotId] = useState<string | null>(null);
  const [facilityEStop, setFacilityEStop] = useState(false);
  const [showEStopModal, setShowEStopModal] = useState(false);

  // Audio tone effect for E-stop alert
  const playAlertTone = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(440, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.2);
      gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.3);
    } catch {
      // AudioContext may be blocked before interaction, safe fallback
    }
  };

  // Main simulation heartbeat loop
  useEffect(() => {
    if (!isSimRunning) return;

    const intervalTime = Math.max(200, Math.round(800 / simSpeed));
    const interval = setInterval(() => {
      // 1. Advance robot positions and task progression
      setRobots((currentRobots) => {
        setTasks((currentTasks) => {
          const { updatedRobots, updatedTasks } = updateAmrSimulation(
            currentRobots,
            currentTasks,
            obstacles,
            facilityEStop,
            simSpeed
          );

          // 2. Auto-dispatch engine (if active and facility not e-stopped)
          if (autoDispatchEnabled && !facilityEStop) {
            const queuedTasks = updatedTasks.filter((t) => t.status === 'queued');
            if (queuedTasks.length > 0) {
              for (const qTask of queuedTasks) {
                const allocation = autoAllocateTask(qTask, updatedRobots);
                if (allocation.bestRobotId) {
                  const targetAmr = updatedRobots.find((r) => r.id === allocation.bestRobotId);
                  if (targetAmr && targetAmr.status === 'idle') {
                    // Plan path from robot position to task source
                    const pickupPath = findWarehousePath(targetAmr.position, qTask.sourceLocation);
                    targetAmr.path = pickupPath;
                    targetAmr.pathIndex = 0;
                    targetAmr.targetPosition = qTask.sourceLocation;
                    targetAmr.status = 'in_transit';
                    targetAmr.currentTaskId = qTask.id;
                    targetAmr.payloadKg = qTask.weightKg;

                    qTask.assignedAmrId = targetAmr.id;
                    qTask.status = 'moving_to_pickup';
                    qTask.startedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
                  }
                }
              }
            }
          }

          // Accumulate operational hours & tonnage
          setMetrics((prev) => ({
            ...prev,
            totalFleetHours: Number((prev.totalFleetHours + 0.002 * simSpeed).toFixed(1)),
          }));

          return updatedTasks;
        });

        return currentRobots;
      });
    }, intervalTime);

    return () => clearInterval(interval);
  }, [isSimRunning, simSpeed, obstacles, facilityEStop, autoDispatchEnabled]);

  // E-Stop Handlers
  const handleTriggerGlobalEStop = () => {
    playAlertTone();
    setFacilityEStop(true);
    setRobots((prev) =>
      prev.map((r) => ({
        ...r,
        status: 'e_stop',
        speed: 0,
      }))
    );
  };

  const handleOpenResetEStop = () => {
    setShowEStopModal(true);
  };

  const handleConfirmResetEStop = () => {
    setFacilityEStop(false);
    setShowEStopModal(false);
    setRobots((prev) =>
      prev.map((r) => ({
        ...r,
        status: r.path.length > 0 ? 'in_transit' : 'idle',
      }))
    );
  };

  // Robot selection and manual controls
  const handleSendToCharge = (robotId: string) => {
    setRobots((prev) =>
      prev.map((r) => {
        if (r.id === robotId) {
          const chargePad = { x: 36, y: 54 };
          const path = findWarehousePath(r.position, chargePad);
          return {
            ...r,
            path,
            pathIndex: 0,
            targetPosition: chargePad,
            status: 'in_transit',
            currentTaskId: null,
            payloadKg: 0,
          };
        }
        return r;
      })
    );
  };

  const handleToggleRobotEStop = (robotId: string) => {
    setRobots((prev) =>
      prev.map((r) => {
        if (r.id === robotId) {
          const nextStatus = r.status === 'e_stop' ? (r.path.length > 0 ? 'in_transit' : 'idle') : 'e_stop';
          return {
            ...r,
            status: nextStatus,
            speed: nextStatus === 'e_stop' ? 0 : r.speed,
          };
        }
        return r;
      })
    );
  };

  const handleTeleopMove = (
    robotId: string,
    direction: 'forward' | 'backward' | 'left' | 'right' | 'halt'
  ) => {
    setRobots((prev) =>
      prev.map((r) => {
        if (r.id === robotId) {
          if (direction === 'halt') {
            return { ...r, speed: 0, status: 'idle', path: [] };
          }
          if (direction === 'left') {
            const newHeading = (r.heading - 45 + 360) % 360;
            return { ...r, heading: newHeading };
          }
          if (direction === 'right') {
            const newHeading = (r.heading + 45) % 360;
            return { ...r, heading: newHeading };
          }

          // Forward or backward jog
          const rad = (r.heading * Math.PI) / 180;
          const delta = direction === 'forward' ? 2.5 : -2.5;
          const newX = Math.max(2, Math.min(98, r.position.x + Math.cos(rad) * delta));
          const newY = Math.max(2, Math.min(58, r.position.y + Math.sin(rad) * delta));

          return {
            ...r,
            position: { x: Number(newX.toFixed(2)), y: Number(newY.toFixed(2)) },
            status: 'in_transit',
            speed: 0.8 * r.speedLimiter,
          };
        }
        return r;
      })
    );
  };

  const handleSetSpeedLimiter = (robotId: string, limit: number) => {
    setRobots((prev) =>
      prev.map((r) => (r.id === robotId ? { ...r, speedLimiter: limit } : r))
    );
  };

  // Obstacle simulation
  const handleAddObstacle = (x: number, y: number) => {
    const newObs: Obstacle = {
      id: `obs_${Date.now()}`,
      name: 'Dynamic Maintenance Obstacle',
      x,
      y,
      radius: 3.2,
      type: 'temporary_spill',
      createdAt: new Date().toLocaleTimeString(),
    };
    setObstacles((prev) => [...prev, newObs]);
  };

  const handleClearObstacles = () => {
    setObstacles([]);
    // Restore robots that were blocked
    setRobots((prev) =>
      prev.map((r) => (r.status === 'blocked' ? { ...r, status: r.path.length > 0 ? 'in_transit' : 'idle' } : r))
    );
  };

  // Task allocation
  const handleDispatchTask = (
    newTaskData: Omit<Task, 'id' | 'createdAt' | 'startedAt' | 'completedAt' | 'progressPercent'>,
    assignedRobotId: string | null
  ) => {
    const newId = `TSK-${Math.floor(1000 + Math.random() * 9000)}`;
    const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    const newTask: Task = {
      ...newTaskData,
      id: newId,
      createdAt: currentTime,
      startedAt: assignedRobotId ? currentTime : null,
      completedAt: null,
      progressPercent: 0,
      assignedAmrId: assignedRobotId,
      status: assignedRobotId ? 'moving_to_pickup' : 'queued',
    };

    setTasks((prev) => [newTask, ...prev]);

    if (assignedRobotId) {
      setRobots((prev) =>
        prev.map((r) => {
          if (r.id === assignedRobotId) {
            const pickupPath = findWarehousePath(r.position, newTask.sourceLocation);
            return {
              ...r,
              path: pickupPath,
              pathIndex: 0,
              targetPosition: newTask.sourceLocation,
              status: 'in_transit',
              currentTaskId: newId,
              payloadKg: newTask.weightKg,
            };
          }
          return r;
        })
      );
    }
  };

  const handleCancelTask = (taskId: string) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, status: 'canceled' } : t))
    );
    setRobots((prev) =>
      prev.map((r) => {
        if (r.currentTaskId === taskId) {
          return {
            ...r,
            currentTaskId: null,
            status: 'idle',
            path: [],
            payloadKg: 0,
          };
        }
        return r;
      })
    );
  };

  const handleAutoAllocateAll = () => {
    setTasks((currentTasks) => {
      const updatedTasks = [...currentTasks];
      setRobots((currentRobots) => {
        const updatedRobots = currentRobots.map((r) => ({ ...r }));

        for (const task of updatedTasks) {
          if (task.status === 'queued') {
            const alloc = autoAllocateTask(task, updatedRobots);
            if (alloc.bestRobotId) {
              const r = updatedRobots.find((bot) => bot.id === alloc.bestRobotId);
              if (r && r.status === 'idle') {
                const path = findWarehousePath(r.position, task.sourceLocation);
                r.path = path;
                r.pathIndex = 0;
                r.targetPosition = task.sourceLocation;
                r.status = 'in_transit';
                r.currentTaskId = task.id;
                r.payloadKg = task.weightKg;

                task.assignedAmrId = r.id;
                task.status = 'moving_to_pickup';
                task.startedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
              }
            }
          }
        }
        return updatedRobots;
      });
      return updatedTasks;
    });
  };

  // WMS / MES Sync Handlers
  const handleSyncWms = () => {
    const newOrderId = `SO-OUT-${Math.floor(500 + Math.random() * 500)}`;
    const newWmsOrder: WmsOrder = {
      orderId: newOrderId,
      type: 'outbound_pick',
      customer: 'AeroTech Systems Europe',
      lineItemsCount: 5,
      totalWeightKg: 780,
      assignedWave: 'WAVE-DYNAMIC-SYNC',
      status: 'pending',
      priority: 'P2_HIGH',
      timestamp: new Date().toLocaleTimeString(),
      linkedTasks: [],
    };
    setWmsOrders((prev) => [newWmsOrder, ...prev]);
  };

  const handleSimulateMesConsumption = () => {
    setMesOrders((prev) =>
      prev.map((order) => {
        if (order.workOrderId === 'MES-WO-109') {
          const nextStock = Math.max(8, order.bufferStockLevel - 10);
          return {
            ...order,
            bufferStockLevel: nextStock,
            status: nextStock <= order.minBufferThreshold ? 'starved' : 'replenishing',
          };
        }
        return order;
      })
    );
  };

  const handleConvertWmsOrderToTask = (orderId: string) => {
    const order = wmsOrders.find((o) => o.orderId === orderId);
    if (!order) return;

    handleDispatchTask(
      {
        type: 'outbound_dispatch',
        priority: order.priority,
        sourceZone: 'High-Density Racking Aisle A1',
        sourceLocation: { x: 26, y: 28 },
        sourceBay: 'Rack A1-02',
        destinationZone: 'Outbound Shipping & Sorting',
        destinationLocation: { x: 90, y: 24 },
        destinationBay: 'Shipping Bay S-02',
        sku: 'SKU-AEROSPACE-HARNESS',
        skuDescription: `Order ${order.orderId} for ${order.customer}`,
        weightKg: order.totalWeightKg,
        assignedAmrId: null,
        status: 'queued',
        sourceSystem: 'WMS',
      },
      null
    );

    setWmsOrders((prev) =>
      prev.map((o) => (o.orderId === orderId ? { ...o, status: 'processing' } : o))
    );
  };

  const handleReplenishMesLine = (workOrderId: string) => {
    const mesOrder = mesOrders.find((m) => m.workOrderId === workOrderId);
    if (!mesOrder) return;

    handleDispatchTask(
      {
        type: 'wip_assembly_transfer',
        priority: 'P1_CRITICAL',
        sourceZone: 'High-Density Racking Aisle B1',
        sourceLocation: { x: 54, y: 28 },
        sourceBay: 'Rack B1-02',
        destinationZone: mesOrder.assemblyLine,
        destinationLocation: { x: 48, y: 6 },
        destinationBay: mesOrder.assemblyLine.split(':')[0],
        sku: 'SKU-MES-REPLENISH',
        skuDescription: `${mesOrder.productPart} replenishment batch`,
        weightKg: 210,
        assignedAmrId: null,
        status: 'queued',
        sourceSystem: 'MES',
      },
      null
    );

    setMesOrders((prev) =>
      prev.map((m) => (m.workOrderId === workOrderId ? { ...m, status: 'replenishing', bufferStockLevel: 45 } : m))
    );
  };

  const selectedRobot = robots.find((r) => r.id === selectedRobotId) || null;

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-slate-950 font-sans selection:bg-amber-500/20">
      {/* Top Navigation Bar adhering to Top Bar Contract */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isSimRunning={isSimRunning}
        setIsSimRunning={setIsSimRunning}
        simSpeed={simSpeed}
        setSimSpeed={setSimSpeed}
        facilityEStop={facilityEStop}
        onTriggerGlobalEStop={handleTriggerGlobalEStop}
        onResetGlobalEStop={handleOpenResetEStop}
        autoDispatchEnabled={autoDispatchEnabled}
        setAutoDispatchEnabled={setAutoDispatchEnabled}
      />

      {/* Main Viewport Content */}
      <main className="flex-1 overflow-hidden relative">
        {activeTab === 'digital_twin' && (
          <FacilityMap
            robots={robots}
            zones={zones}
            obstacles={obstacles}
            tasks={tasks}
            selectedRobotId={selectedRobotId}
            onSelectRobot={setSelectedRobotId}
            onAddObstacle={handleAddObstacle}
            onClearObstacles={handleClearObstacles}
            facilityEStop={facilityEStop}
          />
        )}

        {activeTab === 'missions' && (
          <MissionPlanner
            tasks={tasks}
            robots={robots}
            zones={zones}
            onDispatchTask={handleDispatchTask}
            onCancelTask={handleCancelTask}
            onAutoAllocateAll={handleAutoAllocateAll}
            onSelectRobot={(id) => {
              setSelectedRobotId(id);
              setActiveTab('digital_twin');
            }}
          />
        )}

        {activeTab === 'integration' && (
          <IntegrationHub
            wmsOrders={wmsOrders}
            mesOrders={mesOrders}
            onSyncWms={handleSyncWms}
            onSimulateMesConsumption={handleSimulateMesConsumption}
            onConvertWmsOrderToTask={handleConvertWmsOrderToTask}
            onReplenishMesLine={handleReplenishMesLine}
            robots={robots}
          />
        )}

        {activeTab === 'telemetry' && (
          <TelemetryAnalytics robots={robots} metrics={metrics} />
        )}

        {activeTab === 'raas' && (
          <RaasEconomics metrics={metrics} robots={robots} />
        )}

        {/* Robot Detail / Teleoperation Drawer */}
        <RobotDetailModal
          robot={selectedRobot}
          tasks={tasks}
          onClose={() => setSelectedRobotId(null)}
          onSendToCharge={handleSendToCharge}
          onToggleRobotEStop={handleToggleRobotEStop}
          onTeleopMove={handleTeleopMove}
          onSetSpeedLimiter={handleSetSpeedLimiter}
        />

        {/* Global Facility E-Stop Interlock Modal */}
        <GlobalEmergencyModal
          isOpen={showEStopModal}
          robots={robots}
          onConfirmReset={handleConfirmResetEStop}
          onCancel={() => setShowEStopModal(false)}
        />
      </main>
    </div>
  );
}

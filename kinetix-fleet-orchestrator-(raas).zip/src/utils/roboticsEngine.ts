import {
  AmrRobot,
  Task,
  Position2D,
  Waypoint,
  Obstacle,
  Vda5050Order,
} from '../types/robotics';

// Main highway corridors in the warehouse to prevent cutting through high-bay racks:
// North corridor: y = 10
// Middle cross corridor: y = 30
// South corridor: y = 46
// West aisle: x = 18
// Central aisle: x = 48
// East aisle: x = 78

export function findWarehousePath(start: Position2D, end: Position2D): Waypoint[] {
  const waypoints: Waypoint[] = [{ x: start.x, y: start.y }];

  // Choose the closest horizontal corridor
  const corridors = [10, 30, 46];
  const startCorridor = corridors.reduce((prev, curr) =>
    Math.abs(curr - start.y) < Math.abs(prev - start.y) ? curr : prev
  );
  const endCorridor = corridors.reduce((prev, curr) =>
    Math.abs(curr - end.y) < Math.abs(prev - end.y) ? curr : prev
  );

  // If already close or in same column
  if (Math.abs(start.x - end.x) < 4 && Math.abs(start.y - end.y) < 6) {
    waypoints.push({ x: end.x, y: end.y, action: 'drop' });
    return waypoints;
  }

  // 1. Move from start to nearest corridor
  if (Math.abs(start.y - startCorridor) > 1.5) {
    waypoints.push({ x: start.x, y: startCorridor });
  }

  // 2. Choose vertical transit artery (x=18, 48, or 78)
  const arteries = [18, 48, 78];
  const chosenArtery = arteries.reduce((prev, curr) =>
    Math.abs(curr - start.x) < Math.abs(prev - start.x) ? curr : prev
  );

  // Move along start corridor to chosen artery if switching corridors
  if (startCorridor !== endCorridor) {
    waypoints.push({ x: chosenArtery, y: startCorridor });
    waypoints.push({ x: chosenArtery, y: endCorridor });
  }

  // 3. Move along end corridor toward destination X
  waypoints.push({ x: end.x, y: endCorridor });

  // 4. Move into destination spot
  waypoints.push({ x: end.x, y: end.y, action: 'drop' });

  return waypoints;
}

export function calculateDistance(a: Position2D, b: Position2D): number {
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  return Math.sqrt(dx * dx + dy * dy);
}

export function updateAmrSimulation(
  robots: AmrRobot[],
  tasks: Task[],
  obstacles: Obstacle[],
  facilityEStop: boolean,
  speedMultiplier: number = 1.0
): { updatedRobots: AmrRobot[]; updatedTasks: Task[] } {
  const tasksMap = new Map(tasks.map((t) => [t.id, { ...t }]));

  const updatedRobots = robots.map((robot) => {
    const r = { ...robot };

    // If global E-Stop is active or individual E-Stop
    if (facilityEStop || r.status === 'e_stop') {
      r.speed = 0;
      return r;
    }

    // Charging behavior
    if (r.status === 'charging') {
      r.speed = 0;
      r.batterySoc = Math.min(100, Number((r.batterySoc + 0.3 * speedMultiplier).toFixed(1)));
      r.batteryVoltage = 53.4;
      r.motorTempC = Math.max(26.0, Number((r.motorTempC - 0.1 * speedMultiplier).toFixed(1)));

      if (r.batterySoc >= 95) {
        r.status = 'idle';
      }
      return r;
    }

    // Check for obstacles ahead
    let obstacleBlocked = false;
    for (const obs of obstacles) {
      const dist = calculateDistance(r.position, { x: obs.x, y: obs.y });
      if (dist < obs.radius + 1.8) {
        obstacleBlocked = true;
        break;
      }
    }

    if (obstacleBlocked) {
      r.status = 'blocked';
      r.speed = 0;
      r.lidarClearance = 1.2;
      return r;
    } else if (r.status === 'blocked') {
      r.status = r.path.length > 0 ? 'in_transit' : 'idle';
    }

    // Transit along waypoints
    if (r.status === 'in_transit' && r.path.length > 0 && r.pathIndex < r.path.length) {
      const targetWp = r.path[r.pathIndex];
      const dx = targetWp.x - r.position.x;
      const dy = targetWp.y - r.position.y;
      const distToWp = Math.sqrt(dx * dx + dy * dy);

      // Check for proximity to other AMRs (collision avoidance / safety cushion)
      let peerTooClose = false;
      for (const other of robots) {
        if (other.id !== r.id && other.status === 'in_transit') {
          const peerDist = calculateDistance(r.position, other.position);
          if (peerDist < 2.8) {
            // Lower ID yields to higher ID or whoever has lower priority
            if (r.id > other.id) {
              peerTooClose = true;
              break;
            }
          }
        }
      }

      if (peerTooClose) {
        r.speed = Math.max(0.2, r.speed * 0.7);
      } else {
        r.speed = Math.min(r.maxSpeed * r.speedLimiter, r.speed + 0.2 * speedMultiplier);
      }

      // Desired angle
      const targetAngle = (Math.atan2(dy, dx) * 180) / Math.PI;
      // Heading normalized
      r.heading = Math.round(targetAngle >= 0 ? targetAngle : 360 + targetAngle);

      // Step movement
      const stepDistance = (r.speed * 0.45 * speedMultiplier);

      if (distToWp <= Math.max(0.6, stepDistance)) {
        // Reached this waypoint
        r.position = { x: targetWp.x, y: targetWp.y };
        r.pathIndex += 1;

        // If reached the end of path
        if (r.pathIndex >= r.path.length) {
          r.speed = 0;
          r.path = [];
          r.pathIndex = 0;
          r.targetPosition = null;

          // Complete or progress task if associated
          if (r.currentTaskId && tasksMap.has(r.currentTaskId)) {
            const task = tasksMap.get(r.currentTaskId)!;
            if (task.status === 'moving_to_pickup') {
              task.status = 'loading';
              task.progressPercent = 50;
              // Generate path from pickup to destination
              const destPath = findWarehousePath(task.sourceLocation, task.destinationLocation);
              r.path = destPath;
              r.pathIndex = 0;
              r.targetPosition = task.destinationLocation;
              r.status = 'in_transit';
              task.status = 'moving_to_drop';
            } else {
              task.status = 'completed';
              task.progressPercent = 100;
              task.completedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
              r.currentTaskId = null;
              r.payloadKg = 0;
              r.status = 'idle';
            }
          } else {
            r.status = 'idle';
          }
        }
      } else {
        // Advance toward target waypoint
        const ratio = stepDistance / distToWp;
        r.position = {
          x: Number((r.position.x + dx * ratio).toFixed(2)),
          y: Number((r.position.y + dy * ratio).toFixed(2)),
        };
      }

      // Update distance and battery
      r.totalDistanceKm = Number((r.totalDistanceKm + (r.speed * 0.0004 * speedMultiplier)).toFixed(2));
      const batteryDrain = (0.015 + (r.payloadKg / r.maxPayloadKg) * 0.02) * speedMultiplier;
      r.batterySoc = Math.max(5, Number((r.batterySoc - batteryDrain).toFixed(2)));
      r.batteryVoltage = Number((44.0 + (r.batterySoc / 100) * 8.4).toFixed(1));
      r.motorTempC = Math.min(65.0, Number((r.motorTempC + 0.02 * (r.speed / r.maxSpeed) * speedMultiplier).toFixed(1)));

      // If battery is critically low (<18%) and idle/not already charging, return to charging station
      if (r.batterySoc < 18 && !r.currentTaskId) {
        const chargingPad: Position2D = { x: 36, y: 54 };
        r.path = findWarehousePath(r.position, chargingPad);
        r.pathIndex = 0;
        r.targetPosition = chargingPad;
        r.status = 'in_transit';
      }

      // Update task progress percent if in progress
      if (r.currentTaskId && tasksMap.has(r.currentTaskId)) {
        const task = tasksMap.get(r.currentTaskId)!;
        if (task.status === 'moving_to_drop' && r.path.length > 0) {
          const ratio = r.pathIndex / r.path.length;
          task.progressPercent = Math.min(95, Math.round(50 + ratio * 45));
        }
      }
    }

    // Realistic LiDAR clearance simulation
    let nearestClearance = 10.0;
    for (const other of robots) {
      if (other.id !== r.id) {
        const d = calculateDistance(r.position, other.position);
        if (d < nearestClearance) nearestClearance = d;
      }
    }
    r.lidarClearance = Number(nearestClearance.toFixed(1));

    // Wi-Fi signal simulation based on distance from AP (AP located at center 50, 30)
    const distToAp = calculateDistance(r.position, { x: 50, y: 30 });
    r.wifiRssi = Math.round(-40 - distToAp * 0.4);

    return r;
  });

  return {
    updatedRobots,
    updatedTasks: Array.from(tasksMap.values()),
  };
}

export function autoAllocateTask(
  task: Task,
  robots: AmrRobot[]
): { bestRobotId: string | null; score: number; rationale: string } {
  const eligible = robots.filter((r) => {
    if (r.status === 'e_stop' || r.status === 'error') return false;
    if (r.batterySoc < 22) return false;
    if (r.maxPayloadKg < task.weightKg) return false;
    return true;
  });

  if (eligible.length === 0) {
    return {
      bestRobotId: null,
      score: 0,
      rationale: 'No eligible AMR with sufficient payload capacity (> ' + task.weightKg + 'kg) and >22% battery.',
    };
  }

  let bestAmr: AmrRobot | null = null;
  let bestScore = -Infinity;
  let bestDist = 0;

  for (const r of eligible) {
    const dist = calculateDistance(r.position, task.sourceLocation);
    // Cost formula:
    // Base idle bonus + battery factor - distance penalty
    let score = 100;
    if (r.status === 'idle') score += 60;
    if (r.status === 'charging' && r.batterySoc > 70) score += 20;
    if (r.status === 'in_transit') score -= 30; // already busy

    score += r.batterySoc * 0.5;
    score -= dist * 2.2;

    if (score > bestScore) {
      bestScore = score;
      bestAmr = r;
      bestDist = dist;
    }
  }

  if (!bestAmr) {
    return { bestRobotId: null, score: 0, rationale: 'Score evaluation failed.' };
  }

  return {
    bestRobotId: bestAmr.id,
    score: Math.round(bestScore),
    rationale: `Selected ${bestAmr.callsign} (${bestAmr.id}): Distance ${bestDist.toFixed(1)}m, Battery ${bestAmr.batterySoc}%, Max load ${bestAmr.maxPayloadKg}kg.`,
  };
}

export function generateVda5050Order(robot: AmrRobot, task: Task): Vda5050Order {
  const timestamp = new Date().toISOString();
  return {
    header: {
      headerId: Math.floor(Math.random() * 1000000),
      timestamp,
      version: '2.0.0',
      manufacturer: 'KINETIX Robotics GmbH',
      serialNumber: robot.id,
    },
    orderId: `ORD-${task.id}`,
    orderUpdateId: 0,
    zoneSetId: 'WAREHOUSE_MAIN_FLOOR',
    nodes: [
      {
        nodeId: `node_source_${task.sourceBay.replace(/\s+/g, '_')}`,
        sequenceId: 0,
        released: true,
        nodePosition: {
          x: task.sourceLocation.x,
          y: task.sourceLocation.y,
          mapId: 'MAP_A1_LEVEL_0',
        },
        actions: [
          {
            actionType: 'pickPayload',
            actionId: `act_pick_${task.id}`,
            actionParameters: {
              sku: task.sku,
              expectedWeightKg: task.weightKg,
              sourceBay: task.sourceBay,
            },
          },
        ],
      },
      {
        nodeId: `node_dest_${task.destinationBay.replace(/\s+/g, '_')}`,
        sequenceId: 1,
        released: true,
        nodePosition: {
          x: task.destinationLocation.x,
          y: task.destinationLocation.y,
          mapId: 'MAP_A1_LEVEL_0',
        },
        actions: [
          {
            actionType: 'dropPayload',
            actionId: `act_drop_${task.id}`,
            actionParameters: {
              sku: task.sku,
              destinationBay: task.destinationBay,
            },
          },
        ],
      },
    ],
    edges: [
      {
        edgeId: `edge_corridor_01`,
        sequenceId: 0,
        released: true,
        startNodeId: `node_source_${task.sourceBay.replace(/\s+/g, '_')}`,
        endNodeId: `node_dest_${task.destinationBay.replace(/\s+/g, '_')}`,
        maxSpeed: robot.maxSpeed,
      },
    ],
  };
}

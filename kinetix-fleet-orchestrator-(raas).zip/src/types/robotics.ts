/**
 * Core domain types for KINETIX Robotics Fleet Management (RaaS)
 * Compliant with VDA 5050 AMR standard specifications
 */

export type AmrStatus = 'idle' | 'in_transit' | 'charging' | 'blocked' | 'error' | 'e_stop';

export type AmrModelType =
  | 'Titan-1500 (Heavy Pallet Lifter)'
  | 'AgileTug-300 (Tote Shutter)'
  | 'ConveyorBot-600 (Cart Conveyor)'
  | 'PrecisionArm-120 (Mobile Manipulator)';

export interface Position2D {
  x: number; // 0 to 100 meters
  y: number; // 0 to 60 meters
}

export interface Waypoint extends Position2D {
  id?: string;
  zoneName?: string;
  action?: 'pickup' | 'drop' | 'charge' | 'inspect' | 'transit';
}

export interface AmrRobot {
  id: string;
  callsign: string;
  model: AmrModelType;
  status: AmrStatus;
  position: Position2D;
  targetPosition: Position2D | null;
  path: Waypoint[];
  pathIndex: number;
  heading: number; // 0 - 360 degrees
  speed: number; // m/s (0 to 2.2)
  maxSpeed: number; // m/s
  speedLimiter: number; // 0.1 to 1.0 multiplier
  batterySoc: number; // 0 - 100%
  batteryVoltage: number; // Volts
  batteryHealth: number; // % SOH
  payloadKg: number;
  maxPayloadKg: number;
  currentTaskId: string | null;
  currentOrderId: string | null;
  wifiRssi: number; // dBm (-30 to -85)
  lidarClearance: number; // meters to closest obstacle
  motorTempC: number; // Celsius
  totalDistanceKm: number;
  operatingHours: number;
  firmware: string;
  ipAddress: string;
  diagnosticFaults: {
    code: string;
    severity: 'info' | 'warning' | 'critical';
    message: string;
    timestamp: string;
  }[];
  lidarPoints?: { angle: number; distance: number }[]; // polar coordinates for scanner
}

export type TaskPriority = 'P1_CRITICAL' | 'P2_HIGH' | 'P3_NORMAL' | 'P4_LOW';

export type TaskType =
  | 'pallet_transport'
  | 'rack_replenish'
  | 'outbound_dispatch'
  | 'wip_assembly_transfer'
  | 'bin_shuttle'
  | 'dock_staging'
  | 'return_to_charger';

export type TaskStatus =
  | 'queued'
  | 'assigned'
  | 'moving_to_pickup'
  | 'loading'
  | 'moving_to_drop'
  | 'unloading'
  | 'completed'
  | 'canceled';

export interface Task {
  id: string;
  type: TaskType;
  priority: TaskPriority;
  sourceZone: string;
  sourceLocation: Position2D;
  sourceBay: string;
  destinationZone: string;
  destinationLocation: Position2D;
  destinationBay: string;
  sku: string;
  skuDescription: string;
  weightKg: number;
  assignedAmrId: string | null;
  status: TaskStatus;
  progressPercent: number;
  createdAt: string;
  startedAt: string | null;
  completedAt: string | null;
  sourceSystem: 'WMS' | 'MES' | 'MANUAL_DISPATCH';
  notes?: string;
}

export interface WmsOrder {
  orderId: string;
  type: 'outbound_pick' | 'inbound_putaway' | 'cross_dock' | 'cycle_count';
  customer: string;
  lineItemsCount: number;
  totalWeightKg: number;
  assignedWave: string;
  status: 'pending' | 'processing' | 'staged' | 'shipped';
  priority: TaskPriority;
  timestamp: string;
  linkedTasks: string[];
}

export interface MesWorkOrder {
  workOrderId: string;
  assemblyLine: string;
  productPart: string;
  batchLot: string;
  bufferStockLevel: number; // %
  minBufferThreshold: number; // %
  status: 'starved' | 'replenishing' | 'nominal' | 'completed';
  requiredPartsPerHr: number;
  lastDelivery: string;
  linkedTaskId: string | null;
}

export interface WarehouseZone {
  id: string;
  name: string;
  type: 'dock' | 'racks' | 'charging' | 'mes_line' | 'shipping' | 'keep_out' | 'transit_aisle';
  bounds: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  color: string;
  isActive: boolean;
  bays?: { name: string; x: number; y: number }[];
}

export interface Vda5050Header {
  headerId: number;
  timestamp: string;
  version: string;
  manufacturer: string;
  serialNumber: string;
}

export interface Vda5050Order {
  header: Vda5050Header;
  orderId: string;
  orderUpdateId: number;
  zoneSetId: string;
  nodes: {
    nodeId: string;
    sequenceId: number;
    released: boolean;
    nodePosition: {
      x: number;
      y: number;
      mapId: string;
    };
    actions: {
      actionType: string;
      actionId: string;
      actionParameters?: Record<string, unknown>;
    }[];
  }[];
  edges: {
    edgeId: string;
    sequenceId: number;
    released: boolean;
    startNodeId: string;
    endNodeId: string;
    maxSpeed: number;
  }[];
}

export interface RaaSMetrics {
  totalFleetHours: number;
  activeRobotCount: number;
  totalTonnageMoved: number;
  slaAvailabilityPercent: number;
  targetSlaPercent: number;
  costPerPalletRaaS: number; // e.g. $0.21
  costPerPalletForklift: number; // e.g. $1.38
  totalCostSavedMonth: number;
  batteryThroughputKwh: number;
  safetyIncidentCount: number;
  averageCycleTimeMinutes: number;
}

export interface Obstacle {
  id: string;
  name: string;
  x: number;
  y: number;
  radius: number;
  type: 'temporary_spill' | 'manual_pallet' | 'maintenance_cordon' | 'pedestrian';
  createdAt: string;
}
